## https://gameofthrones.fandom.com/wiki/The_Sword_in_the_Darkness

## Contents
- [1 Premise](#Premise)
- [2 Cast](#Cast)
- [3 Gallery](#Gallery)
- [3.1 Video](#Video)
- [3.2 Images](#Images)
- [4 References](#References)
- [4.1 Notes](#Notes)
- [5 External links](#External_links)
in: [Pages on non-canon media](/wiki/Category:Pages_on_non-canon_media "Category:Pages on non-canon media"), [Episodes directed by Graham Ross](/wiki/Category:Episodes_directed_by_Graham_Ross "Category:Episodes directed by Graham Ross"), [Episodes of Game of Thrones: A Telltale Games Series](/wiki/Category:Episodes_of_Game_of_Thrones:_A_Telltale_Games_Series "Category:Episodes of Game of Thrones: A Telltale Games Series"),
and [4 more](null)
- [Episodes released in 2015](/wiki/Category:Episodes_released_in_2015 "Category:Episodes released in 2015")
- [Episodes written by Dan Martin](/wiki/Category:Episodes_written_by_Dan_Martin "Category:Episodes written by Dan Martin")
- [Episodes written by John Dombrow](/wiki/Category:Episodes_written_by_John_Dombrow "Category:Episodes written by John Dombrow")
- [Episodes written by Joshua Rubin](/wiki/Category:Episodes_written_by_Joshua_Rubin "Category:Episodes written by Joshua Rubin")
English
- [Deutsch](https://gameofthrones.fandom.com/de/wiki/Das_Schwert_in_der_Dunkelheit_(Episode))
- [Français](https://gameofthrones.fandom.com/fr/wiki/L%27%C3%89p%C3%A9e_dans_les_T%C3%A9n%C3%A8bres)
- [Русский](https://gameofthrones.fandom.com/ru/wiki/%D0%9C%D0%B5%D1%87_%D0%B2%D0%BE_%D1%82%D1%8C%D0%BC%D0%B5)
# The Sword in the Darkness
[Sign in to edit](https://auth.fandom.com/signin?redirect=https%3A%2F%2Fgameofthrones.fandom.com%2Fwiki%2FThe_Sword_in_the_Darkness%3Fveaction%3Dedit&uselang=en)
- [History](/wiki/The_Sword_in_the_Darkness?action=history)
- [Purge](/wiki/The_Sword_in_the_Darkness?action=purge)
- [Talk (0)](/wiki/Talk:The_Sword_in_the_Darkness?action=edit&redlink=1)
Netflix: Electric State Cast Interview
We sat down with the cast of Electric State, coming March 14th on Netflix.
Keep WatchingNext video in 8 seconds
More Videos
0 of 2 minutes, 51 secondsVolume 0%
Press shift question mark to access a list of keyboard shortcuts
Keyboard ShortcutsEnabledDisabled
Shortcuts Open/Close/ or ?
Play/PauseSPACE
Increase Volume↑
Decrease Volume↓
Seek Forward→
Seek Backward←
Captions On/Offc
Fullscreen/Exit Fullscreenf
Mute/Unmutem
Decrease Caption Size\-
Increase Caption Size\+ or =
Seek %0-9
Auto720p1080p720p406p270p180p
0.5x1x1.25x1.5x2x
Live
00:11
02:39
02:51
_This page is about the episode. For the order who vow to be the swords in the darkness, see: [Night's Watch](/wiki/Night%27s_Watch "Night's Watch")_
## The Sword in the Darkness
_[Game of Thrones:A Telltale Games Series](/wiki/Game_of_Thrones:_A_Telltale_Games_Series "Game of Thrones: A Telltale Games Series")_[\[5\]](#cite_note-ATGS-6)
[![ATGS03](https://static.wikia.nocookie.net/gameofthrones/images/3/36/ATGS03.png/revision/latest/scale-to-width-down/268?cb=20150320175902)
](https://static.wikia.nocookie.net/gameofthrones/images/3/36/ATGS03.png/revision/latest?cb=20150320175902 "ATGS03")
Episode 3[\[2\]](#cite_note-ATGS_03-2)
## Episode information
### Release date(s)
March 24, 2015[\[1\]](#cite_note-EW-1) (PlayStation 4, PlayStation 3)March 25, 2015[\[1\]](#cite_note-EW-1) (Xbox One, Xbox 360)March 26, 2015[\[1\]](#cite_note-EW-1) (iOS, Android)
### Written by
Dan Martin[\[2\]](#cite_note-ATGS_03-2)John Dombrow[\[2\]](#cite_note-ATGS_03-2)Joshua Rubin[\[2\]](#cite_note-ATGS_03-2)
### Directed by
Graham Ross[\[2\]](#cite_note-ATGS_03-2)
## Chronological information
### Year
[301 AC](/wiki/301_AC/Non-canon "301 AC/Non-canon")[\[a\]](#cite_note-The_Sword_in_the_Darkness_year-3)
← **Previous**
**Next** →
"[The Lost Lords](/wiki/The_Lost_Lords "The Lost Lords")"[\[3\]](#cite_note-ATGS_02-4)
"[Sons of Winter](/wiki/Sons_of_Winter "Sons of Winter")"[\[4\]](#cite_note-ATGS_04-5)
"**The Sword in the Darkness**"[\[2\]](#cite_note-ATGS_03-2) is the third episode of _[Game of Thrones: A Telltale Games Series](/wiki/Game_of_Thrones:_A_Telltale_Games_Series "Game of Thrones: A Telltale Games Series")_. It premiered on March 24, 2015. It was written by Dan Martin, John Dombrow, and Joshua Rubin, and directed by Graham Ross.
## Contents
- [1 Premise](#Premise)
- [2 Cast](#Cast)
- [3 Gallery](#Gallery)
- [3.1 Video](#Video)
- [3.2 Images](#Images)
- [4 References](#References)
- [4.1 Notes](#Notes)
- [5 External links](#External_links)
Advertisement
## Premise\[\]
_Asher, the [exile](/wiki/Exile "Exile"), heads to [Mereen](/wiki/Meereen "Meereen")\[sic\] in search of an army to take on the Whitehills. Meanwhile, far across land and sea in [Westeros](/wiki/Westeros "Westeros"), Mira must deal with the lethal politics of [King's Landing](/wiki/King%27s_Landing "King's Landing"). Her [family](/wiki/Noble_house "Noble house")'s safety is paramount and she will do anything to protect them, but nothing is given freely, and her choice of allies may soon come to haunt her. To the [north](/wiki/North "North"), in Ironrath, the Whitehill occupation continues. Gryff Whitehill, fourth-born son, is out to prove himself, and brutality and violence grows daily, pushing the Forresters to make far-reaching decisions. Finally, at the [Wall](/wiki/Wall "Wall"), Gared learns that he must head [north](/wiki/Beyond_the_Wall "Beyond the Wall") if he is to help his house survive. But fate is cruel, forcing choices that will change his path forever._[\[6\]](#cite_note-ATGS_03_Trailer-7)
## Cast\[\]
- [Emilia Clarke](/wiki/Emilia_Clarke "Emilia Clarke") as [Daenerys Targaryen](/wiki/Daenerys_Targaryen "Daenerys Targaryen")
- [Peter Dinklage](/wiki/Peter_Dinklage "Peter Dinklage") as [Tyrion Lannister](/wiki/Tyrion_Lannister "Tyrion Lannister")
- [Natalie Dormer](/wiki/Natalie_Dormer "Natalie Dormer") as [Margaery Tyrell](/wiki/Margaery_Tyrell "Margaery Tyrell")
- [Kit Harington](/wiki/Kit_Harington "Kit Harington") as [Jon Snow](/wiki/Jon_Snow "Jon Snow")
- [Lena Headey](/wiki/Lena_Headey "Lena Headey") as [Cersei Lannister](/wiki/Cersei_Lannister "Cersei Lannister")
- [Iwan Rheon](/wiki/Iwan_Rheon "Iwan Rheon") as [Ramsay Snow](/wiki/Ramsay_Bolton "Ramsay Bolton")
- Russ Bain as Rodrik
- Alex Jordan as Asher
- Daniel Kendrick as Gared Tuttle
- Martha Mackintosh as Mira Forrester
- Christopher Nelson as Ethan Forrester
- Laura Bailey as Gwyn
- Joseph Balderrama as Cotter
- JB Blanc as Malcom Forrester,\[sic\] Thermund, Father Tuttle
- Jeremy Crutchley as Denner Frostfinger
- Sacha Dhawin\[sic\] as Gryff Whitehill
- Robin Atkin Downes as Lord Forrester, Duncan Tuttle & Andros
- David Franklin as Maester Ortengryn
- Brian George as Ser Royland Degore & Tazal
- Alastair James as Britt
- Geoff Leesley as Lord Whitehill & Norren
- Natasha Loring as Sera
- Yuri Lowenthal as Finn, Tom & Erik
- Matthew Mercer as Bowen & Fegg
- Toks Olagundoye as Beskha
- Amy Pemberton as Elaena
- Lara Pulver as Lady Forrester
- Molly Stone as Talia Forrester
- Louis Suc as Ryon Forrester
- Fabio Tassone as Lucan
- Owen Thomas as Damien
- Oliver Vaquer as Morgryn
- Adam Leadbeater as Croft, Whitehill Soldier
- Ron Bottitta as Harys, Whitehill Soldier, Lannister Soldier
- Matt Wolf as Whitehill Soldier, Lannister Soldier
Advertisement
## Gallery\[\]
### Video\[\]
[![](https://static.wikia.nocookie.net/gameofthrones/images/c/cc/Game_of_Thrones-_A_Telltale_Games_Series_Episode_Three-_%22The_Sword_in_the_Darkness%22_Trailer/revision/latest/scale-to-width-down/185?cb=20211015015314 "Game of Thrones: A Telltale Games Series Episode Three: "The Sword in the Darkness" Trailer (28 KB)")](/wiki/File:Game_of_Thrones:_A_Telltale_Games_Series_Episode_Three:_%22The_Sword_in_the_Darkness%22_Trailer "Game of Thrones: A Telltale Games Series Episode Three: "The Sword in the Darkness" Trailer (28 KB)")
Game of Thrones: A Telltale Games Series Episode Three: "The Sword in the Darkness" Trailer
### Images\[\]
[![](https://static.wikia.nocookie.net/gameofthrones/images/b/bd/TSITD_Pre-Release_1.png/revision/latest/scale-to-width-down/185?cb=20150320175936 "TSITD Pre-Release 1.png (2.37 MB)")
](/wiki/File:TSITD_Pre-Release_1.png "TSITD Pre-Release 1.png (2.37 MB)")
[![](https://static.wikia.nocookie.net/gameofthrones/images/d/d9/TSITD_Pre-Release_2.png/revision/latest/scale-to-width-down/185?cb=20150320180018 "TSITD Pre-Release 2.png (3.9 MB)")
](/wiki/File:TSITD_Pre-Release_2.png "TSITD Pre-Release 2.png (3.9 MB)")
[![](https://static.wikia.nocookie.net/gameofthrones/images/f/f8/TSITD_Pre-Release_3.png/revision/latest/scale-to-width-down/185?cb=20150320180049 "TSITD Pre-Release 3.png (2.73 MB)")
](/wiki/File:TSITD_Pre-Release_3.png "TSITD Pre-Release 3.png (2.73 MB)")
[![](https://static.wikia.nocookie.net/gameofthrones/images/e/e0/TSITD_Pre-Release_4.png/revision/latest/scale-to-width-down/185?cb=20150320180128 "TSITD Pre-Release 4.png (4.05 MB)")
](/wiki/File:TSITD_Pre-Release_4.png "TSITD Pre-Release 4.png (4.05 MB)")
[![](https://static.wikia.nocookie.net/gameofthrones/images/d/df/TSITD_Pre-Release_5.png/revision/latest/scale-to-width-down/185?cb=20150320180204 "TSITD Pre-Release 5.png (4.37 MB)")
](/wiki/File:TSITD_Pre-Release_5.png "TSITD Pre-Release 5.png (4.37 MB)")
## References\[\]
1. ↑ [Jump up to: 1.0](#cite_ref-EW_1-0) [1.1](#cite_ref-EW_1-1) [1.2](#cite_ref-EW_1-2) Jonathon Dornbush (March 23, 2015). [Watch Telltale's 'Game of Thrones' episode 3 trailer](https://ew.com/article/2015/03/23/telltale-game-of-thrones-episode-3-trailer-release-date/). _Entertainment Weekly_. Retrieved February 3, 2024.
2. ↑ [Jump up to: 2.0](#cite_ref-ATGS_03_2-0) [2.1](#cite_ref-ATGS_03_2-1) [2.2](#cite_ref-ATGS_03_2-2) [2.3](#cite_ref-ATGS_03_2-3) [2.4](#cite_ref-ATGS_03_2-4) [2.5](#cite_ref-ATGS_03_2-5) _[Game of Thrones: A Telltale Games Series](/wiki/Game_of_Thrones:_A_Telltale_Games_Series "Game of Thrones: A Telltale Games Series")_, Episode 3: "**The Sword in the Darkness**" (2015).
3. [↑](#cite_ref-ATGS_02_4-0 "Jump up") _[Game of Thrones: A Telltale Games Series](/wiki/Game_of_Thrones:_A_Telltale_Games_Series "Game of Thrones: A Telltale Games Series")_, Episode 2: "[The Lost Lords](/wiki/The_Lost_Lords "The Lost Lords")" (2015).
4. [↑](#cite_ref-ATGS_04_5-0 "Jump up") _[Game of Thrones: A Telltale Games Series](/wiki/Game_of_Thrones:_A_Telltale_Games_Series "Game of Thrones: A Telltale Games Series")_, Episode 4: "[Sons of Winter](/wiki/Sons_of_Winter "Sons of Winter")" (2015).
5. [↑](#cite_ref-ATGS_6-0 "Jump up") _[Game of Thrones: A Telltale Games Series](/wiki/Game_of_Thrones:_A_Telltale_Games_Series "Game of Thrones: A Telltale Games Series")_ (2014).
6. [↑](#cite_ref-ATGS_03_Trailer_7-0 "Jump up") Telltale Games (March 23, 2015). [Game of Thrones: A Telltale Games Series Episode Three: "The Sword in the Darkness" Trailer](https://www.youtube.com/watch?v=Q6d2EYm6KJI). _YouTube_. Retrieved January 20, 2024.
### Notes\[\]
1. [↑](#cite_ref-The_Sword_in_the_Darkness_year_3-0 "Jump up") "**The Sword in the Darkness**" depicts the Purple Wedding featured in "[The Lion and the Rose](/wiki/The_Lion_and_the_Rose "The Lion and the Rose");" therefore, the final four episodes of the game take place in 301 AC.
Advertisement
## External links\[\]
- [![](https://static.wikia.nocookie.net/gameofthrones/images/f/fd/TTGOT_favicon.png/revision/latest/scale-to-width-down/25?cb=20220219080350)](https://static.wikia.nocookie.net/gameofthrones/images/f/fd/TTGOT_favicon.png/revision/latest?cb=20220219080350) [The Sword in the Darkness](https://ttgot.fandom.com/wiki/The_Sword_in_the_Darkness "w:c:ttgot:The Sword in the Darkness") on [Telltale's Game Of Thrones Wiki](https://ttgot.fandom.com/wiki/ "w:c:ttgot")
\[hide\]
[v](/wiki/Template:Game_of_Thrones-_A_Telltale_Games_Series "Template:Game of Thrones- A Telltale Games Series") • [d](https://gameofthrones.fandom.com/wiki/Template_talk:Game_of_Thrones-_A_Telltale_Games_Series) • [e](https://gameofthrones.fandom.com/wiki/Template:Game_of_Thrones-_A_Telltale_Games_Series?action=edit)
_[Game of Thrones: A Telltale Games Series](/wiki/Game_of_Thrones:_A_Telltale_Games_Series "Game of Thrones: A Telltale Games Series")_
**[Individuals](/wiki/Category:Individuals_from_Game_of_Thrones:_A_Telltale_Games_Series "Category:Individuals from Game of Thrones: A Telltale Games Series")**
[Cersei Lannister](/wiki/Cersei_Lannister "Cersei Lannister") · [Tyrion Lannister](/wiki/Tyrion_Lannister "Tyrion Lannister") · [Margaery Tyrell](/wiki/Margaery_Tyrell "Margaery Tyrell") · [Ramsay Snow](/wiki/Ramsay_Bolton "Ramsay Bolton") · [Jon Snow](/wiki/Jon_Snow "Jon Snow") · [Daenerys Targaryen](/wiki/Daenerys_Targaryen "Daenerys Targaryen")
**[Cast members](/wiki/Category:Cast_members_of_Game_of_Thrones:_A_Telltale_Games_Series "Category:Cast members of Game of Thrones: A Telltale Games Series")**
[Lena Headey](/wiki/Lena_Headey "Lena Headey") · [Peter Dinklage](/wiki/Peter_Dinklage "Peter Dinklage") · [Natalie Dormer](/wiki/Natalie_Dormer "Natalie Dormer") · [Iwan Rheon](/wiki/Iwan_Rheon "Iwan Rheon") · [Kit Harington](/wiki/Kit_Harington "Kit Harington") · [Emilia Clarke](/wiki/Emilia_Clarke "Emilia Clarke")
**[Episodes](/wiki/Category:Episodes_of_Game_of_Thrones:_A_Telltale_Games_Series "Category:Episodes of Game of Thrones: A Telltale Games Series")**
[Iron From Ice](/wiki/Iron_From_Ice "Iron From Ice") · [The Lost Lords](/wiki/The_Lost_Lords "The Lost Lords") · **The Sword in the Darkness** · [Sons of Winter](/wiki/Sons_of_Winter "Sons of Winter") · [A Nest of Vipers](/wiki/A_Nest_of_Vipers "A Nest of Vipers") · [The Ice Dragon](/wiki/The_Ice_Dragon "The Ice Dragon")
\[hide\]
[v](/wiki/Template:Game_of_Thrones "Template:Game of Thrones") • [d](https://gameofthrones.fandom.com/wiki/Template_talk:Game_of_Thrones) • [e](https://gameofthrones.fandom.com/wiki/Template:Game_of_Thrones?action=edit)
_[Game of Thrones](/wiki/Game_of_Thrones "Game of Thrones")_
**[Showrunners](/wiki/Category:Showrunners_of_Game_of_Thrones "Category:Showrunners of Game of Thrones")**
[David Benioff](/wiki/David_Benioff "David Benioff") · [D.B. Weiss](/wiki/D.B._Weiss "D.B. Weiss")
**[Individuals](/wiki/Category:Individuals_from_Game_of_Thrones "Category:Individuals from Game of Thrones")**
[Eddard Stark](/wiki/Eddard_Stark "Eddard Stark") · [Robert Baratheon](/wiki/Robert_Baratheon "Robert Baratheon") · [Tyrion Lannister](/wiki/Tyrion_Lannister "Tyrion Lannister") · [Jaime Lannister](/wiki/Jaime_Lannister "Jaime Lannister") · [Cersei Lannister](/wiki/Cersei_Lannister "Cersei Lannister") · [Daenerys Targaryen](/wiki/Daenerys_Targaryen "Daenerys Targaryen") · [Jon Snow](/wiki/Jon_Snow "Jon Snow") · [Petyr Baelish](/wiki/Petyr_Baelish "Petyr Baelish") · [Robb Stark](/wiki/Robb_Stark "Robb Stark") · [Catelyn Stark](/wiki/Catelyn_Stark "Catelyn Stark") · [Viserys Targaryen](/wiki/Viserys_Targaryen_(son_of_Aerys_II) "Viserys Targaryen (son of Aerys II)") · [Tywin Lannister](/wiki/Tywin_Lannister "Tywin Lannister") · [Margaery Tyrell](/wiki/Margaery_Tyrell "Margaery Tyrell") · [Stannis Baratheon](/wiki/Stannis_Baratheon "Stannis Baratheon") · [Sansa Stark](/wiki/Sansa_Stark "Sansa Stark") · [Arya Stark](/wiki/Arya_Stark "Arya Stark") · [Davos Seaworth](/wiki/Davos_Seaworth "Davos Seaworth") · [Melisandre](/wiki/Melisandre "Melisandre") · [Missandei](/wiki/Missandei "Missandei") · [Ellaria Sand](/wiki/Ellaria_Sand "Ellaria Sand") · [Joffrey Baratheon](/wiki/Joffrey_Baratheon "Joffrey Baratheon") · [Theon Greyjoy](/wiki/Theon_Greyjoy "Theon Greyjoy") · [Gendry Baratheon](/wiki/Gendry_Baratheon "Gendry Baratheon") · [Bran Stark](/wiki/Bran_Stark "Bran Stark") · [Samwell Tarly](/wiki/Samwell_Tarly "Samwell Tarly") · [Talisa Stark](/wiki/Talisa_Stark "Talisa Stark") · [Gilly](/wiki/Gilly "Gilly") · [Jeor Mormont](/wiki/Jeor_Mormont "Jeor Mormont") · [Tommen Baratheon](/wiki/Tommen_Baratheon "Tommen Baratheon") · [Brienne of Tarth](/wiki/Brienne_of_Tarth "Brienne of Tarth") · [Varys](/wiki/Varys "Varys") · [Sandor Clegane](/wiki/Sandor_Clegane "Sandor Clegane") · [Daario Naharis](/wiki/Daario_Naharis "Daario Naharis") · [High Sparrow](/wiki/High_Sparrow "High Sparrow") · [Ramsay Bolton](/wiki/Ramsay_Bolton "Ramsay Bolton") · [Roose Bolton](/wiki/Roose_Bolton "Roose Bolton") · [Bronn](/wiki/Bronn "Bronn") · [Tormund](/wiki/Tormund "Tormund") · [Shae](/wiki/Shae "Shae") · [Ygritte](/wiki/Ygritte "Ygritte") · [Jaqen H'ghar](/wiki/Jaqen_H%27ghar "Jaqen H'ghar") · [Grey Worm](/wiki/Grey_Worm "Grey Worm") · [Jorah Mormont](/wiki/Jorah_Mormont "Jorah Mormont")
**[Cast members](/wiki/Category:Cast_members_of_Game_of_Thrones "Category:Cast members of Game of Thrones")**
[Starring cast](/wiki/Starring_cast_(Game_of_Thrones) "Starring cast (Game of Thrones)"): [Sean Bean](/wiki/Sean_Bean "Sean Bean") · [Mark Addy](/wiki/Mark_Addy "Mark Addy") · [Peter Dinklage](/wiki/Peter_Dinklage "Peter Dinklage") · [Nikolaj Coster-Waldau](/wiki/Nikolaj_Coster-Waldau "Nikolaj Coster-Waldau") · [Lena Headey](/wiki/Lena_Headey "Lena Headey") · [Emilia Clarke](/wiki/Emilia_Clarke "Emilia Clarke") · [Kit Harington](/wiki/Kit_Harington "Kit Harington") · [Aidan Gillen](/wiki/Aidan_Gillen "Aidan Gillen") · [Richard Madden](/wiki/Richard_Madden "Richard Madden") · [Michelle Fairley](/wiki/Michelle_Fairley "Michelle Fairley") · [Harry Lloyd](/wiki/Harry_Lloyd "Harry Lloyd") · [Charles Dance](/wiki/Charles_Dance "Charles Dance") · [Natalie Dormer](/wiki/Natalie_Dormer "Natalie Dormer") · [Stephen Dillane](/wiki/Stephen_Dillane "Stephen Dillane") · [Sophie Turner](/wiki/Sophie_Turner "Sophie Turner") · [Maisie Williams](/wiki/Maisie_Williams "Maisie Williams") · [Liam Cunningham](/wiki/Liam_Cunningham "Liam Cunningham") · [Carice van Houten](/wiki/Carice_van_Houten "Carice van Houten") · [Nathalie Emmanuel](/wiki/Nathalie_Emmanuel "Nathalie Emmanuel") · [Indira Varma](/wiki/Indira_Varma "Indira Varma") · [Jack Gleeson](/wiki/Jack_Gleeson "Jack Gleeson") · [Alfie Allen](/wiki/Alfie_Allen "Alfie Allen") · [Joe Dempsie](/wiki/Joe_Dempsie "Joe Dempsie") · [Isaac Hempstead-Wright](/wiki/Isaac_Hempstead-Wright "Isaac Hempstead-Wright") · [John Bradley](/wiki/John_Bradley "John Bradley") · [Oona Chaplin](/wiki/Oona_Chaplin "Oona Chaplin") · [Hannah Murray](/wiki/Hannah_Murray "Hannah Murray") · [James Cosmo](/wiki/James_Cosmo "James Cosmo") · [Dean-Charles Chapman](/wiki/Dean-Charles_Chapman "Dean-Charles Chapman") · [Gwendoline Christie](/wiki/Gwendoline_Christie "Gwendoline Christie") · [Conleth Hill](/wiki/Conleth_Hill "Conleth Hill") · [Rory McCann](/wiki/Rory_McCann "Rory McCann") · [Michiel Huisman](/wiki/Michiel_Huisman "Michiel Huisman") · [Jonathan Pryce](/wiki/Jonathan_Pryce "Jonathan Pryce") · [Iwan Rheon](/wiki/Iwan_Rheon "Iwan Rheon") · [Michael McElhatton](/wiki/Michael_McElhatton "Michael McElhatton") · [Jerome Flynn](/wiki/Jerome_Flynn "Jerome Flynn") · [Kristofer Hivju](/wiki/Kristofer_Hivju "Kristofer Hivju") · [Sibel Kekilli](/wiki/Sibel_Kekilli "Sibel Kekilli") · [Rose Leslie](/wiki/Rose_Leslie "Rose Leslie") · [Tom Wlaschiha](/wiki/Tom_Wlaschiha "Tom Wlaschiha") · [Jacob Anderson](/wiki/Jacob_Anderson "Jacob Anderson") · [Iain Glen](/wiki/Iain_Glen "Iain Glen")
**[Seasons](/wiki/Category:Seasons_of_Game_of_Thrones "Category:Seasons of Game of Thrones")**
[Season 1](/wiki/Game_of_Thrones:_Season_1 "Game of Thrones: Season 1") ([cast](/wiki/Game_of_Thrones:_Season_1/Cast "Game of Thrones: Season 1/Cast")) · [Season 2](/wiki/Game_of_Thrones:_Season_2 "Game of Thrones: Season 2") ([cast](/wiki/Game_of_Thrones:_Season_2/Cast "Game of Thrones: Season 2/Cast")) · [Season 3](/wiki/Game_of_Thrones:_Season_3 "Game of Thrones: Season 3") ([cast](/wiki/Game_of_Thrones:_Season_3/Cast "Game of Thrones: Season 3/Cast")) · [Season 4](/wiki/Game_of_Thrones:_Season_4 "Game of Thrones: Season 4") ([cast](/wiki/Game_of_Thrones:_Season_4/Cast "Game of Thrones: Season 4/Cast")) · [Season 5](/wiki/Game_of_Thrones:_Season_5 "Game of Thrones: Season 5") ([cast](/wiki/Game_of_Thrones:_Season_5/Cast "Game of Thrones: Season 5/Cast")) · [Season 6](/wiki/Game_of_Thrones:_Season_6 "Game of Thrones: Season 6") ([cast](/wiki/Game_of_Thrones:_Season_6/Cast "Game of Thrones: Season 6/Cast")) · [Season 7](/wiki/Game_of_Thrones:_Season_7 "Game of Thrones: Season 7") ([cast](/wiki/Game_of_Thrones:_Season_7/Cast "Game of Thrones: Season 7/Cast")) · [Season 8](/wiki/Game_of_Thrones:_Season_8 "Game of Thrones: Season 8") ([cast](/wiki/Game_of_Thrones:_Season_8/Cast "Game of Thrones: Season 8/Cast"))
**[Episodes](/wiki/Category:Episodes_of_Game_of_Thrones "Category:Episodes of Game of Thrones")**
**[Season 1](/wiki/Category:Episodes_of_Game_of_Thrones:_Season_1 "Category:Episodes of Game of Thrones: Season 1")**
[Winter Is Coming](/wiki/Winter_Is_Coming "Winter Is Coming") ([appearances](/wiki/Winter_Is_Coming/Appearances "Winter Is Coming/Appearances")) · [The Kingsroad](/wiki/The_Kingsroad "The Kingsroad") ([appearances](/wiki/The_Kingsroad/Appearances "The Kingsroad/Appearances")) · [Lord Snow](/wiki/Lord_Snow "Lord Snow") ([appearances](/wiki/Lord_Snow/Appearances "Lord Snow/Appearances")) · [Cripples, Bastards, and Broken Things](/wiki/Cripples,_Bastards,_and_Broken_Things "Cripples, Bastards, and Broken Things") ([appearances](/wiki/Cripples,_Bastards,_and_Broken_Things/Appearances "Cripples, Bastards, and Broken Things/Appearances")) · [The Wolf and the Lion](/wiki/The_Wolf_and_the_Lion "The Wolf and the Lion") ([appearances](/wiki/The_Wolf_and_the_Lion/Appearances "The Wolf and the Lion/Appearances")) · [A Golden Crown](/wiki/A_Golden_Crown "A Golden Crown") ([appearances](/wiki/A_Golden_Crown/Appearances "A Golden Crown/Appearances")) · [You Win or You Die](/wiki/You_Win_or_You_Die "You Win or You Die") ([appearances](/wiki/You_Win_or_You_Die/Appearances "You Win or You Die/Appearances")) · [The Pointy End](/wiki/The_Pointy_End "The Pointy End") ([appearances](/wiki/The_Pointy_End/Appearances "The Pointy End/Appearances")) · [Baelor](/wiki/Baelor "Baelor") ([appearances](/wiki/Baelor/Appearances "Baelor/Appearances")) · [Fire and Blood](/wiki/Fire_and_Blood "Fire and Blood") ([appearances](/wiki/Fire_and_Blood/Appearances "Fire and Blood/Appearances"))
**[Season 2](/wiki/Category:Episodes_of_Game_of_Thrones:_Season_2 "Category:Episodes of Game of Thrones: Season 2")**
[The North Remembers](/wiki/The_North_Remembers "The North Remembers") ([appearances](/wiki/The_North_Remembers/Appearances "The North Remembers/Appearances")) · [The Night Lands](/wiki/The_Night_Lands "The Night Lands") ([appearances](/wiki/The_Night_Lands/Appearances "The Night Lands/Appearances")) · [What Is Dead May Never Die](/wiki/What_Is_Dead_May_Never_Die "What Is Dead May Never Die") ([appearances](/wiki/What_Is_Dead_May_Never_Die/Appearances "What Is Dead May Never Die/Appearances")) · [Garden of Bones](/wiki/Garden_of_Bones_(episode) "Garden of Bones (episode)") ([appearances](/wiki/Garden_of_Bones_(episode)/Appearances "Garden of Bones (episode)/Appearances")) · [The Ghost of Harrenhal](/wiki/The_Ghost_of_Harrenhal "The Ghost of Harrenhal") ([appearances](/wiki/The_Ghost_of_Harrenhal/Appearances "The Ghost of Harrenhal/Appearances")) · [The Old Gods and the New](/wiki/The_Old_Gods_and_the_New "The Old Gods and the New") ([appearances](/wiki/The_Old_Gods_and_the_New/Appearances "The Old Gods and the New/Appearances")) · [A Man Without Honor](/wiki/A_Man_Without_Honor "A Man Without Honor") ([appearances](/wiki/A_Man_Without_Honor/Appearances "A Man Without Honor/Appearances")) · [The Prince of Winterfell](/wiki/The_Prince_of_Winterfell "The Prince of Winterfell") ([appearances](/wiki/The_Prince_of_Winterfell/Appearances "The Prince of Winterfell/Appearances")) · [Blackwater](/wiki/Blackwater "Blackwater") ([appearances](/wiki/Blackwater/Appearances "Blackwater/Appearances")) · [Valar Morghulis](/wiki/Valar_Morghulis "Valar Morghulis") ([appearances](/wiki/Valar_Morghulis/Appearances "Valar Morghulis/Appearances"))
**[Season 3](/wiki/Category:Episodes_of_Game_of_Thrones:_Season_3 "Category:Episodes of Game of Thrones: Season 3")**
[Valar Dohaeris](/wiki/Valar_Dohaeris "Valar Dohaeris") ([appearances](/wiki/Valar_Dohaeris/Appearances "Valar Dohaeris/Appearances")) · [Dark Wings, Dark Words](/wiki/Dark_Wings,_Dark_Words "Dark Wings, Dark Words") ([appearances](/wiki/Dark_Wings,_Dark_Words/Appearances "Dark Wings, Dark Words/Appearances")) · [Walk of Punishment](/wiki/Walk_of_Punishment_(episode) "Walk of Punishment (episode)") ([appearances](/wiki/Walk_of_Punishment_(episode)/Appearances "Walk of Punishment (episode)/Appearances")) · [And Now His Watch Is Ended](/wiki/And_Now_His_Watch_Is_Ended "And Now His Watch Is Ended") ([appearances](/wiki/And_Now_His_Watch_Is_Ended/Appearances "And Now His Watch Is Ended/Appearances")) · [Kissed by Fire](/wiki/Kissed_by_Fire "Kissed by Fire") ([appearances](/wiki/Kissed_by_Fire/Appearances "Kissed by Fire/Appearances")) · [The Climb](/wiki/The_Climb "The Climb") ([appearances](/wiki/The_Climb/Appearances "The Climb/Appearances")) · [The Bear and the Maiden Fair](/wiki/The_Bear_and_the_Maiden_Fair_(episode) "The Bear and the Maiden Fair (episode)") ([appearances](/wiki/The_Bear_and_the_Maiden_Fair_(episode)/Appearances "The Bear and the Maiden Fair (episode)/Appearances")) · [Second Sons](/wiki/Second_Sons_(episode) "Second Sons (episode)") ([appearances](/wiki/Second_Sons_(episode)/Appearances "Second Sons (episode)/Appearances")) · [The Rains of Castamere](/wiki/The_Rains_of_Castamere_(episode) "The Rains of Castamere (episode)") ([appearances](/wiki/The_Rains_of_Castamere_(episode)/Appearances "The Rains of Castamere (episode)/Appearances")) · [Mhysa](/wiki/Mhysa "Mhysa") ([appearances](/wiki/Mhysa/Appearances "Mhysa/Appearances"))
**[Season 4](/wiki/Category:Episodes_of_Game_of_Thrones:_Season_4 "Category:Episodes of Game of Thrones: Season 4")**
[Two Swords](/wiki/Two_Swords "Two Swords") ([appearances](/wiki/Two_Swords/Appearances "Two Swords/Appearances")) · [The Lion and the Rose](/wiki/The_Lion_and_the_Rose "The Lion and the Rose") ([appearances](/wiki/The_Lion_and_the_Rose/Appearances "The Lion and the Rose/Appearances")) · [Breaker of Chains](/wiki/Breaker_of_Chains "Breaker of Chains") ([appearances](/wiki/Breaker_of_Chains/Appearances "Breaker of Chains/Appearances")) · [Oathkeeper](/wiki/Oathkeeper_(episode) "Oathkeeper (episode)") ([appearances](/wiki/Oathkeeper_(episode)/Appearances "Oathkeeper (episode)/Appearances")) · [First of His Name](/wiki/First_of_His_Name "First of His Name") ([appearances](/wiki/First_of_His_Name/Appearances "First of His Name/Appearances")) · [The Laws of Gods and Men](/wiki/The_Laws_of_Gods_and_Men "The Laws of Gods and Men") ([appearances](/wiki/The_Laws_of_Gods_and_Men/Appearances "The Laws of Gods and Men/Appearances")) · [Mockingbird](/wiki/Mockingbird "Mockingbird") ([appearances](/wiki/Mockingbird/Appearances "Mockingbird/Appearances")) · [The Mountain and the Viper](/wiki/The_Mountain_and_the_Viper "The Mountain and the Viper") ([appearances](/wiki/The_Mountain_and_the_Viper/Appearances "The Mountain and the Viper/Appearances")) · [The Watchers on the Wall](/wiki/The_Watchers_on_the_Wall "The Watchers on the Wall") ([appearances](/wiki/The_Watchers_on_the_Wall/Appearances "The Watchers on the Wall/Appearances")) · [The Children](/wiki/The_Children "The Children") ([appearances](/wiki/The_Children/Appearances "The Children/Appearances"))
**[Season 5](/wiki/Category:Episodes_of_Game_of_Thrones:_Season_5 "Category:Episodes of Game of Thrones: Season 5")**
[The Wars To Come](/wiki/The_Wars_To_Come "The Wars To Come") ([appearances](/wiki/The_Wars_To_Come/Appearances "The Wars To Come/Appearances")) · [The House of Black and White](/wiki/The_House_of_Black_and_White "The House of Black and White") ([appearances](/wiki/The_House_of_Black_and_White/Appearances "The House of Black and White/Appearances")) · [High Sparrow](/wiki/High_Sparrow_(episode) "High Sparrow (episode)") ([appearances](/wiki/High_Sparrow_(episode)/Appearances "High Sparrow (episode)/Appearances")) · [Sons of the Harpy](/wiki/Sons_of_the_Harpy_(episode) "Sons of the Harpy (episode)") ([appearances](/wiki/Sons_of_the_Harpy_(episode)/Appearances "Sons of the Harpy (episode)/Appearances")) · [Kill the Boy](/wiki/Kill_the_Boy "Kill the Boy") ([appearances](/wiki/Kill_the_Boy/Appearances "Kill the Boy/Appearances")) · [Unbowed, Unbent, Unbroken](/wiki/Unbowed,_Unbent,_Unbroken "Unbowed, Unbent, Unbroken") ([appearances](/wiki/Unbowed,_Unbent,_Unbroken/Appearances "Unbowed, Unbent, Unbroken/Appearances")) · [The Gift](/wiki/The_Gift "The Gift") ([appearances](/wiki/The_Gift/Appearances "The Gift/Appearances")) · [Hardhome](/wiki/Hardhome_(episode) "Hardhome (episode)") ([appearances](/wiki/Hardhome_(episode)/Appearances "Hardhome (episode)/Appearances")) · [The Dance of Dragons](/wiki/The_Dance_of_Dragons_(episode) "The Dance of Dragons (episode)") ([appearances](/wiki/The_Dance_of_Dragons_(episode)/Appearances "The Dance of Dragons (episode)/Appearances")) · [Mother's Mercy](/wiki/Mother%27s_Mercy "Mother's Mercy") ([appearances](/wiki/Mother%27s_Mercy/Appearances "Mother's Mercy/Appearances"))
**[Season 6](/wiki/Category:Episodes_of_Game_of_Thrones:_Season_6 "Category:Episodes of Game of Thrones: Season 6")**
[The Red Woman](/wiki/The_Red_Woman "The Red Woman") ([appearances](/wiki/The_Red_Woman/Appearances "The Red Woman/Appearances")) · [Home](/wiki/Home "Home") ([appearances](/wiki/Home/Appearances "Home/Appearances")) · [Oathbreaker](/wiki/Oathbreaker "Oathbreaker") ([appearances](/wiki/Oathbreaker/Appearances "Oathbreaker/Appearances")) · [Book of the Stranger](/wiki/Book_of_the_Stranger "Book of the Stranger") ([appearances](/wiki/Book_of_the_Stranger/Appearances "Book of the Stranger/Appearances")) · [The Door](/wiki/The_Door "The Door") ([appearances](/wiki/The_Door/Appearances "The Door/Appearances")) · [Blood of My Blood](/wiki/Blood_of_My_Blood "Blood of My Blood") ([appearances](/wiki/Blood_of_My_Blood/Appearances "Blood of My Blood/Appearances")) · [The Broken Man](/wiki/The_Broken_Man "The Broken Man") ([appearances](/wiki/The_Broken_Man/Appearances "The Broken Man/Appearances")) · [No One](/wiki/No_One "No One") ([appearances](/wiki/No_One/Appearances "No One/Appearances")) · [Battle of the Bastards](/wiki/Battle_of_the_Bastards_(episode) "Battle of the Bastards (episode)") ([appearances](/wiki/Battle_of_the_Bastards_(episode)/Appearances "Battle of the Bastards (episode)/Appearances")) · [The Winds of Winter](/wiki/The_Winds_of_Winter "The Winds of Winter") ([appearances](/wiki/The_Winds_of_Winter/Appearances "The Winds of Winter/Appearances"))
**[Season 7](/wiki/Category:Episodes_of_Game_of_Thrones:_Season_7 "Category:Episodes of Game of Thrones: Season 7")**
[Dragonstone](/wiki/Dragonstone_(episode) "Dragonstone (episode)") ([appearances](/wiki/Dragonstone_(episode)/Appearances "Dragonstone (episode)/Appearances")) · [Stormborn](/wiki/Stormborn "Stormborn") ([appearances](/wiki/Stormborn/Appearances "Stormborn/Appearances")) · [The Queen's Justice](/wiki/The_Queen%27s_Justice "The Queen's Justice") ([appearances](/wiki/The_Queen%27s_Justice/Appearances "The Queen's Justice/Appearances")) · [The Spoils of War](/wiki/The_Spoils_of_War "The Spoils of War") ([appearances](/wiki/The_Spoils_of_War/Appearances "The Spoils of War/Appearances")) · [Eastwatch](/wiki/Eastwatch "Eastwatch") ([appearances](/wiki/Eastwatch/Appearances "Eastwatch/Appearances")) · [Beyond the Wall](/wiki/Beyond_the_Wall_(episode) "Beyond the Wall (episode)") ([appearances](/wiki/Beyond_the_Wall_(episode)/Appearances "Beyond the Wall (episode)/Appearances")) · [The Dragon and the Wolf](/wiki/The_Dragon_and_the_Wolf "The Dragon and the Wolf") ([appearances](/wiki/The_Dragon_and_the_Wolf/Appearances "The Dragon and the Wolf/Appearances"))
**[Season 8](/wiki/Category:Episodes_of_Game_of_Thrones:_Season_8 "Category:Episodes of Game of Thrones: Season 8")**
[Winterfell](/wiki/Winterfell_(Game_of_Thrones) "Winterfell (Game of Thrones)") ([appearances](/wiki/Winterfell_(Game_of_Thrones)/Appearances "Winterfell (Game of Thrones)/Appearances")) · [A Knight of the Seven Kingdoms](/wiki/A_Knight_of_the_Seven_Kingdoms_(Game_of_Thrones) "A Knight of the Seven Kingdoms (Game of Thrones)") ([appearances](/wiki/A_Knight_of_the_Seven_Kingdoms_(Game_of_Thrones)/Appearances "A Knight of the Seven Kingdoms (Game of Thrones)/Appearances")) · [The Long Night](/wiki/The_Long_Night "The Long Night") ([appearances](/wiki/The_Long_Night/Appearances "The Long Night/Appearances")) · [The Last of the Starks](/wiki/The_Last_of_the_Starks "The Last of the Starks") ([appearances](/wiki/The_Last_of_the_Starks/Appearances "The Last of the Starks/Appearances")) · [The Bells](/wiki/The_Bells "The Bells") ([appearances](/wiki/The_Bells/Appearances "The Bells/Appearances")) · [The Iron Throne](/wiki/The_Iron_Throne "The Iron Throne") ([appearances](/wiki/The_Iron_Throne/Appearances "The Iron Throne/Appearances"))
**[Pilot](/wiki/Pilot_(Game_of_Thrones) "Pilot (Game of Thrones)")**
[Pilot](/wiki/Pilot_(Game_of_Thrones) "Pilot (Game of Thrones)")
**[Websites](/wiki/Category:Websites_of_Game_of_Thrones "Category:Websites of Game of Thrones")**
[Making _Game of Thrones_](/wiki/Making_Game_of_Thrones "Making Game of Thrones") · [_Game of Thrones_ Viewer's Guide](/wiki/Game_of_Thrones_Viewer%27s_Guide "Game of Thrones Viewer's Guide")
**[Games](/wiki/Category:Games_based_on_Game_of_Thrones "Category:Games based on Game of Thrones")**
[The Maester's Path](/wiki/The_Maester%27s_Path "The Maester's Path") · _[Game of Thrones](/wiki/Game_of_Thrones_(game) "Game of Thrones (game)")_ · _[Battle for the Iron Throne](/wiki/Battle_for_the_Iron_Throne "Battle for the Iron Throne")_ · _[Game of Thrones: Ascent](/wiki/Game_of_Thrones:_Ascent "Game of Thrones: Ascent")_ · _[Game of Thrones: Seven Kingdoms](/wiki/Game_of_Thrones:_Seven_Kingdoms "Game of Thrones: Seven Kingdoms")_ (canceled) · _[Game of Thrones: A Telltale Games Series](/wiki/Game_of_Thrones:_A_Telltale_Games_Series "Game of Thrones: A Telltale Games Series")_ ([Episode 1](/wiki/Iron_From_Ice "Iron From Ice") · [2](/wiki/The_Lost_Lords "The Lost Lords") · **3** · [4](/wiki/Sons_of_Winter "Sons of Winter") · [5](/wiki/A_Nest_of_Vipers "A Nest of Vipers") · [6](/wiki/The_Ice_Dragon "The Ice Dragon")) · _[Game of Thrones: Conquest](/wiki/Game_of_Thrones:_Conquest "Game of Thrones: Conquest")_ · _[Reigns: Game of Thrones](/wiki/Reigns:_Game_of_Thrones "Reigns: Game of Thrones")_ · _[Game of Thrones Slots Casino](/wiki/Game_of_Thrones_Slots_Casino "Game of Thrones Slots Casino")_ · _[Game of Thrones Winter is Coming](/wiki/Game_of_Thrones_Winter_is_Coming "Game of Thrones Winter is Coming")_ · _[Game of Thrones Beyond the Wall](/wiki/Game_of_Thrones_Beyond_the_Wall "Game of Thrones Beyond the Wall")_ · _[Game of Thrones: Tale of Crows](/wiki/Game_of_Thrones:_Tale_of_Crows "Game of Thrones: Tale of Crows")_ · _[Game of Thrones: Legends](/wiki/Game_of_Thrones:_Legends "Game of Thrones: Legends")_ · _[Game of Thrones: Kingsroad](/wiki/Game_of_Thrones:_Kingsroad "Game of Thrones: Kingsroad")_
**[Music](/wiki/Category:Music_from_Game_of_Thrones "Category:Music from Game of Thrones")**
**[Themes and leitmotifs](/wiki/Category:Themes_and_leitmotifs "Category:Themes and leitmotifs")**
[Themes and leitmotifs](/wiki/Themes_and_leitmotifs_(Game_of_Thrones) "Themes and leitmotifs (Game of Thrones)")
**[Albums](/wiki/Category:Albums_of_Game_of_Thrones "Category:Albums of Game of Thrones")**
_[Game of Thrones (Music from the HBO Series)](/wiki/Game_of_Thrones_(Music_from_the_HBO_Series) "Game of Thrones (Music from the HBO Series)")_ · _[Game of Thrones: Season 2 (Music from the HBO Series)](/wiki/Game_of_Thrones:_Season_2_(Music_from_the_HBO_Series) "Game of Thrones: Season 2 (Music from the HBO Series)")_ · _[Game of Thrones: Season 3 (Music from the HBO Series)](/wiki/Game_of_Thrones:_Season_3_(Music_from_the_HBO_Series) "Game of Thrones: Season 3 (Music from the HBO Series)")_ · _Catch the Throne: The Mixtape_ · _[Game of Thrones: Season 4 (Music from the HBO Series)](/wiki/Game_of_Thrones:_Season_4_(Music_from_the_HBO_Series) "Game of Thrones: Season 4 (Music from the HBO Series)")_ · _Catch the Throne: The Mixtape, Volume II_ · _[Game of Thrones: Season 5 (Music from the HBO Series)](/wiki/Game_of_Thrones:_Season_5_(Music_from_the_HBO_Series) "Game of Thrones: Season 5 (Music from the HBO Series)")_ · _[Game of Thrones: Season 6 (Music from the HBO Series)](/wiki/Game_of_Thrones:_Season_6_(Music_from_the_HBO_Series) "Game of Thrones: Season 6 (Music from the HBO Series)")_ · _[Game of Thrones: Season 7 (Music from the HBO Series)](/wiki/Game_of_Thrones:_Season_7_(Music_from_the_HBO_Series) "Game of Thrones: Season 7 (Music from the HBO Series)")_ · _[For the Throne (Music Inspired by the HBO Series Game of Thrones)](/wiki/For_the_Throne_(Music_Inspired_by_the_HBO_Series_Game_of_Thrones) "For the Throne (Music Inspired by the HBO Series Game of Thrones)")_ · _[Game of Thrones: Season 8 (Music from the HBO Series)](/wiki/Game_of_Thrones:_Season_8_(Music_from_the_HBO_Series) "Game of Thrones: Season 8 (Music from the HBO Series)")_
**Live event**
_Game of Thrones_ Live Concert Experience
**[Podcast](/wiki/Category:Podcasts_of_Game_of_Thrones "Category:Podcasts of Game of Thrones")**
_Thronecast_
**[Documentaries](/wiki/Category:Documentaries_of_Game_of_Thrones "Category:Documentaries of Game of Thrones")**
_[Game of Thrones: Inside the Episode](/wiki/Game_of_Thrones:_Inside_the_Episode "Game of Thrones: Inside the Episode")_ ([Season 1](/wiki/Game_of_Thrones:_Inside_the_Episode:_Season_1 "Game of Thrones: Inside the Episode: Season 1") · [2](/wiki/Game_of_Thrones:_Inside_the_Episode:_Season_2 "Game of Thrones: Inside the Episode: Season 2") · [3](/wiki/Game_of_Thrones:_Inside_the_Episode:_Season_3 "Game of Thrones: Inside the Episode: Season 3") · [4](/wiki/Game_of_Thrones:_Inside_the_Episode:_Season_4 "Game of Thrones: Inside the Episode: Season 4") · [5](/wiki/Game_of_Thrones:_Inside_the_Episode:_Season_5 "Game of Thrones: Inside the Episode: Season 5") · [6](/wiki/Game_of_Thrones:_Inside_the_Episode:_Season_6 "Game of Thrones: Inside the Episode: Season 6") · [7](/wiki/Game_of_Thrones:_Inside_the_Episode:_Season_7 "Game of Thrones: Inside the Episode: Season 7") · [8](/wiki/Game_of_Thrones:_Inside_the_Episode:_Season_8 "Game of Thrones: Inside the Episode: Season 8")) · _[Game of Thrones: A Day in the Life](/wiki/Game_of_Thrones:_A_Day_in_the_Life "Game of Thrones: A Day in the Life")_ · _[The Game Revealed](/wiki/The_Game_Revealed "The Game Revealed")_ ([Season 6](/wiki/The_Game_Revealed:_Season_6 "The Game Revealed: Season 6") · [7](/wiki/The_Game_Revealed:_Season_7 "The Game Revealed: Season 7") · [8](/wiki/The_Game_Revealed:_Season_8 "The Game Revealed: Season 8")) · _[Game of Thrones: The Last Watch](/wiki/Game_of_Thrones:_The_Last_Watch "Game of Thrones: The Last Watch")_
**[Micro-series](/wiki/Category:Micro-series_of_Game_of_Thrones "Category:Micro-series of Game of Thrones")**
_[Histories & Lore](/wiki/Histories_%26_Lore "Histories & Lore")_ ([Season 1](/wiki/Histories_%26_Lore:_Season_1 "Histories & Lore: Season 1") · [2](/wiki/Histories_%26_Lore:_Season_2 "Histories & Lore: Season 2") · [3](/wiki/Histories_%26_Lore:_Season_3 "Histories & Lore: Season 3") · [4](/wiki/Histories_%26_Lore:_Season_4 "Histories & Lore: Season 4") · [5](/wiki/Histories_%26_Lore:_Season_5 "Histories & Lore: Season 5") · [6](/wiki/Histories_%26_Lore:_Season_6 "Histories & Lore: Season 6") · [7](/wiki/Histories_%26_Lore:_Season_7 "Histories & Lore: Season 7") · [8](/wiki/Histories_%26_Lore:_Season_8 "Histories & Lore: Season 8"))
**[Books](/wiki/Category:Books_based_on_Game_of_Thrones "Category:Books based on Game of Thrones")**
_[Inside HBO's Game of Thrones](/wiki/Inside_HBO%27s_Game_of_Thrones "Inside HBO's Game of Thrones")_ · _[Game of Thrones: A Pop-Up Guide to Westeros](/wiki/Game_of_Thrones:_A_Pop-Up_Guide_to_Westeros "Game of Thrones: A Pop-Up Guide to Westeros")_ · _[Living Language Dothraki](/wiki/Living_Language_Dothraki "Living Language Dothraki")_ · _[Inside HBO's Game of Thrones: Seasons 3 & 4](/wiki/Inside_HBO%27s_Game_of_Thrones:_Seasons_3_%26_4 "Inside HBO's Game of Thrones: Seasons 3 & 4")_ · _[Game of Thrones: The Noble Houses of Westeros](/wiki/Game_of_Thrones:_The_Noble_Houses_of_Westeros "Game of Thrones: The Noble Houses of Westeros")_ · _Game of Thrones: The Storyboards_ · _Game of Thrones: The Costumes_ · _The Art of Game of Thrones_ · _The Photography of Game of Thrones_ · _[The Official Westeros Cookbook](/wiki/The_Official_Westeros_Cookbook "The Official Westeros Cookbook")_
**[Aftershows](/wiki/Category:Aftershows_of_Game_of_Thrones "Category:Aftershows of Game of Thrones")**
_Thronecast_ · _[After the Thrones](/wiki/After_the_Thrones "After the Thrones")_
**[Featurettes](/wiki/Category:Featurettes_of_Game_of_Thrones "Category:Featurettes of Game of Thrones")**
_[The Dance of Dragons](/wiki/The_Dance_of_Dragons "The Dance of Dragons")_ · _[Game of Thrones: Conquest & Rebellion: An Animated History of the Seven Kingdoms](/wiki/Game_of_Thrones:_Conquest_%26_Rebellion:_An_Animated_History_of_the_Seven_Kingdoms "Game of Thrones: Conquest & Rebellion: An Animated History of the Seven Kingdoms")_ ([Chapter 1](/wiki/Valyria%27s_Last_Scion:_House_Targaryen "Valyria's Last Scion: House Targaryen") · [2](/wiki/Invasion "Invasion") · [3](/wiki/House_Hoare,_Ironborn_Kings_of_the_Riverlands "House Hoare, Ironborn Kings of the Riverlands") · [4](/wiki/House_Durrandon,_the_Storm_Kings "House Durrandon, the Storm Kings") · [5](/wiki/House_Lannister,_Kings_of_the_Rock_%26_House_Gardener,_Kings_of_the_Reach "House Lannister, Kings of the Rock & House Gardener, Kings of the Reach") · [6](/wiki/House_Stark,_The_Kings_of_Winter "House Stark, The Kings of Winter") · [7](/wiki/House_Arryn,_Kings_of_the_Vale "House Arryn, Kings of the Vale") · [8](/wiki/Aegon,_First_of_His_Name "Aegon, First of His Name") · [9](/wiki/House_Martell,_Princes_of_Dorne "House Martell, Princes of Dorne") · [10](/wiki/The_Last_Dragons "The Last Dragons"))
**Production**
[Production timeline](/wiki/Production_timeline "Production timeline") · [Filming locations](/wiki/Filming_locations_(Game_of_Thrones) "Filming locations (Game of Thrones)") · [Opening credits](/wiki/Opening_credits_(Game_of_Thrones) "Opening credits (Game of Thrones)")
**[Source material](/wiki/Category:A_Song_of_Ice_and_Fire "Category:A Song of Ice and Fire")**
_[A Song of Ice and Fire](/wiki/A_Song_of_Ice_and_Fire "A Song of Ice and Fire")_
**[Differences in adaptation](/wiki/Category:Differences_in_adaptation_of_Game_of_Thrones "Category:Differences in adaptation of Game of Thrones")**
**Seasons**
[Season 1](/wiki/Differences_in_adaptation/Game_of_Thrones:_Season_1 "Differences in adaptation/Game of Thrones: Season 1") · [Season 2](/wiki/Differences_in_adaptation/Game_of_Thrones:_Season_2 "Differences in adaptation/Game of Thrones: Season 2") · [Season 3](/wiki/Differences_in_adaptation/Game_of_Thrones:_Season_3 "Differences in adaptation/Game of Thrones: Season 3") · [Season 4](/wiki/Differences_in_adaptation/Game_of_Thrones:_Season_4 "Differences in adaptation/Game of Thrones: Season 4") · [Season 5](/wiki/Differences_in_adaptation/Game_of_Thrones:_Season_5 "Differences in adaptation/Game of Thrones: Season 5") · [Season 6](/wiki/Differences_in_adaptation/Game_of_Thrones:_Season_6 "Differences in adaptation/Game of Thrones: Season 6") · [Season 7](/wiki/Differences_in_adaptation/Game_of_Thrones:_Season_7 "Differences in adaptation/Game of Thrones: Season 7") · [Season 8](/wiki/Differences_in_adaptation/Game_of_Thrones:_Season_8 "Differences in adaptation/Game of Thrones: Season 8")
**Other**
[Bastard Letter](/wiki/Bastard_Letter "Bastard Letter") · [Character names, appearances, or ages](/wiki/Differences_in_adaptation/Character_names,_appearances,_or_ages "Differences in adaptation/Character names, appearances, or ages") · [New characters](/wiki/Differences_in_adaptation/New_characters "Differences in adaptation/New characters") · [Significantly changed characters](/wiki/Differences_in_adaptation/Significantly_changed_characters "Differences in adaptation/Significantly changed characters") · [Status of women](/wiki/Differences_in_adaptation/Status_of_women "Differences in adaptation/Status of women")
**Miscellaneous**
_[Game of Thrones: The Musical](/wiki/Game_of_Thrones:_The_Musical "Game of Thrones: The Musical")_ · [References to _Game of Thrones_ in other media](/wiki/References_to_Game_of_Thrones_in_other_media "References to Game of Thrones in other media")
Categories
- [Categories](/wiki/Special:Categories "Special:Categories"):
- [Pages on non-canon media](/wiki/Category:Pages_on_non-canon_media "Category:Pages on non-canon media")
- [Episodes directed by Graham Ross](/wiki/Category:Episodes_directed_by_Graham_Ross "Category:Episodes directed by Graham Ross")
- [Episodes of Game of Thrones: A Telltale Games Series](/wiki/Category:Episodes_of_Game_of_Thrones:_A_Telltale_Games_Series "Category:Episodes of Game of Thrones: A Telltale Games Series")
- [Episodes released in 2015](/wiki/Category:Episodes_released_in_2015 "Category:Episodes released in 2015")
- [Episodes written by Dan Martin](/wiki/Category:Episodes_written_by_Dan_Martin "Category:Episodes written by Dan Martin")
- [Episodes written by John Dombrow](/wiki/Category:Episodes_written_by_John_Dombrow "Category:Episodes written by John Dombrow")
- [Episodes written by Joshua Rubin](/wiki/Category:Episodes_written_by_Joshua_Rubin "Category:Episodes written by Joshua Rubin")
[\[Configure Reference Popups\]](#configure-refpopups)
Languages
[Deutsch](https://gameofthrones.fandom.com/de/wiki/Das_Schwert_in_der_Dunkelheit_(Episode)) [Français](https://gameofthrones.fandom.com/fr/wiki/L%27%C3%89p%C3%A9e_dans_les_T%C3%A9n%C3%A8bres) [Русский](https://gameofthrones.fandom.com/ru/wiki/%D0%9C%D0%B5%D1%87_%D0%B2%D0%BE_%D1%82%D1%8C%D0%BC%D0%B5)
Community content is available under [CC-BY-SA](https://www.fandom.com/licensing) unless otherwise noted.
More Fandoms
- [Fantasy](https://www.fandom.com/fancentral/fantasy)
- [Game of Thrones](https://www.fandom.com/universe/game-of-thrones)