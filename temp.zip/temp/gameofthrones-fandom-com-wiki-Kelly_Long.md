## https://gameofthrones.fandom.com/wiki/Kelly_Long

## Contents
- [1 Credits](#Credits)
- [1.1 Guest starring](#Guest_starring)
- [1.2 Stunts](#Stunts)
- [2 See also](#See_also)
- [3 References](#References)
in: [Guest starring cast members of Game of Thrones](/wiki/Category:Guest_starring_cast_members_of_Game_of_Thrones "Category:Guest starring cast members of Game of Thrones"), [Stunt performers of Game of Thrones](/wiki/Category:Stunt_performers_of_Game_of_Thrones "Category:Stunt performers of Game of Thrones")
English
- [Deutsch](https://gameofthrones.fandom.com/de/wiki/Kelly_Long)
- [Français](https://gameofthrones.fandom.com/fr/wiki/Kelly_Long)
# Kelly Long
[Sign in to edit](https://auth.fandom.com/signin?redirect=https%3A%2F%2Fgameofthrones.fandom.com%2Fwiki%2FKelly_Long%3Fveaction%3Dedit&uselang=en)
- [History](/wiki/Kelly_Long?action=history)
- [Purge](/wiki/Kelly_Long?action=purge)
- [Talk (0)](/wiki/Talk:Kelly_Long?action=edit&redlink=1)
Netflix: Electric State Cast Interview
We sat down with the cast of Electric State, coming March 14th on Netflix.
Keep WatchingNext video in 8 seconds
More Videos
0 of 30 secondsVolume 0%
Press shift question mark to access a list of keyboard shortcuts
Keyboard ShortcutsEnabledDisabled
Shortcuts Open/Close/ or ?
Play/PauseSPACE
Increase Volume↑
Decrease Volume↓
Seek Forward→
Seek Backward←
Captions On/Offc
Fullscreen/Exit Fullscreenf
Mute/Unmutem
Decrease Caption Size\-
Increase Caption Size\+ or =
Seek %0-9
0.5x1x1.25x1.5x2x
Auto180p1080p720p406p270p180p
This ad will end in 2
Live
00:28
00:01
00:30
## Kelly Long
[![Kelly Long](https://static.wikia.nocookie.net/gameofthrones/images/0/0a/Kelly_Long.png/revision/latest/scale-to-width-down/268?cb=20130609125312)
](https://static.wikia.nocookie.net/gameofthrones/images/0/0a/Kelly_Long.png/revision/latest?cb=20130609125312 "Kelly Long")
## Information
### Role
[Joyeuse Frey](/wiki/Joyeuse_Frey "Joyeuse Frey")
### First episode
"[Baelor](/wiki/Baelor "Baelor")"
### Last episode
"[The Rains of Castamere](/wiki/The_Rains_of_Castamere_(episode) "The Rains of Castamere (episode)")"
External links
[IMDb](https://www.imdb.com/name/nm4958677/)
[Twitter](https://twitter.com/KellyLongLegs)
**Kelly Long** is an Irish actress.[\[1\]](#cite_note-1) She portrays [Joyeuse Frey](/wiki/Joyeuse_Frey "Joyeuse Frey"), [Walder Frey](/wiki/Walder_Frey "Walder Frey")'s eighth wife, in the [first season](/wiki/Game_of_Thrones:_Season_1 "Game of Thrones: Season 1") episode "[Baelor](/wiki/Baelor "Baelor")" and the [third season](/wiki/Game_of_Thrones:_Season_3 "Game of Thrones: Season 3") episode "[The Rains of Castamere](/wiki/The_Rains_of_Castamere_(episode) "The Rains of Castamere (episode)")".
She also works as a stand-in for [Emilia Clarke](/wiki/Emilia_Clarke "Emilia Clarke"), [Michelle Fairley](/wiki/Michelle_Fairley "Michelle Fairley"), [Lena Headey](/wiki/Lena_Headey "Lena Headey"), and [Sophie Turner](/wiki/Sophie_Turner "Sophie Turner"). She was a stunt horse riding double for [Michelle Fairley](/wiki/Michelle_Fairley "Michelle Fairley") in the [first season](/wiki/Game_of_Thrones:_Season_1 "Game of Thrones: Season 1") episode "[The Wolf and the Lion](/wiki/The_Wolf_and_the_Lion "The Wolf and the Lion")" and [Carice van Houten](/wiki/Carice_van_Houten "Carice van Houten") in the [second season](/wiki/Game_of_Thrones:_Season_2 "Game of Thrones: Season 2") episode "[Garden of Bones](/wiki/Garden_of_Bones_(episode) "Garden of Bones (episode)")". In Season 2, Long began working full-time for _Game of Thrones_ art department.[\[2\]](#cite_note-2)
## Contents
- [1 Credits](#Credits)
- [1.1 Guest starring](#Guest_starring)
- [1.2 Stunts](#Stunts)
- [2 See also](#See_also)
- [3 References](#References)
Advertisement
## Credits\[\]
### Guest starring\[\]
**[_Game of Thrones_: Season 1](/wiki/Game_of_Thrones:_Season_1 "Game of Thrones: Season 1")**
[Winter Is Coming](/wiki/Winter_Is_Coming "Winter Is Coming")
[The Kingsroad](/wiki/The_Kingsroad "The Kingsroad")
[Lord Snow](/wiki/Lord_Snow "Lord Snow")
[Cripples, Bastards, and Broken Things](/wiki/Cripples,_Bastards,_and_Broken_Things "Cripples, Bastards, and Broken Things")
[The Wolf and the Lion](/wiki/The_Wolf_and_the_Lion "The Wolf and the Lion")
[A Golden Crown](/wiki/A_Golden_Crown "A Golden Crown")
[You Win or You Die](/wiki/You_Win_or_You_Die "You Win or You Die")
[The Pointy End](/wiki/The_Pointy_End "The Pointy End")
**[Baelor](/wiki/Baelor "Baelor")**
[Fire and Blood](/wiki/Fire_and_Blood "Fire and Blood")
**[_Game of Thrones_: Season 3](/wiki/Game_of_Thrones:_Season_3 "Game of Thrones: Season 3")**
[Valar Dohaeris](/wiki/Valar_Dohaeris "Valar Dohaeris")
[Dark Wings, Dark Words](/wiki/Dark_Wings,_Dark_Words "Dark Wings, Dark Words")
[Walk of Punishment](/wiki/Walk_of_Punishment_(episode) "Walk of Punishment (episode)")
[And Now His Watch Is Ended](/wiki/And_Now_His_Watch_Is_Ended "And Now His Watch Is Ended")
[Kissed by Fire](/wiki/Kissed_by_Fire "Kissed by Fire")
[The Climb](/wiki/The_Climb "The Climb")
[The Bear and the Maiden Fair](/wiki/The_Bear_and_the_Maiden_Fair_(episode) "The Bear and the Maiden Fair (episode)")
[Second Sons](/wiki/Second_Sons_(episode) "Second Sons (episode)")
**[The Rains of Castamere](/wiki/The_Rains_of_Castamere_(episode) "The Rains of Castamere (episode)")**
[Mhysa](/wiki/Mhysa "Mhysa")
### Stunts\[\]
**[_Game of Thrones_: Season 1](/wiki/Game_of_Thrones:_Season_1 "Game of Thrones: Season 1")**
[Winter Is Coming](/wiki/Winter_Is_Coming "Winter Is Coming")
[The Kingsroad](/wiki/The_Kingsroad "The Kingsroad")
[Lord Snow](/wiki/Lord_Snow "Lord Snow")
[Cripples, Bastards, and Broken Things](/wiki/Cripples,_Bastards,_and_Broken_Things "Cripples, Bastards, and Broken Things")
**[The Wolf and the Lion](/wiki/The_Wolf_and_the_Lion "The Wolf and the Lion")**
[A Golden Crown](/wiki/A_Golden_Crown "A Golden Crown")
[You Win or You Die](/wiki/You_Win_or_You_Die "You Win or You Die")
[The Pointy End](/wiki/The_Pointy_End "The Pointy End")
[Baelor](/wiki/Baelor "Baelor")
[Fire and Blood](/wiki/Fire_and_Blood "Fire and Blood")
**[_Game of Thrones_: Season 2](/wiki/Game_of_Thrones:_Season_2 "Game of Thrones: Season 2")**
[The North Remembers](/wiki/The_North_Remembers "The North Remembers")
[The Night Lands](/wiki/The_Night_Lands "The Night Lands")
[What Is Dead May Never Die](/wiki/What_Is_Dead_May_Never_Die "What Is Dead May Never Die")
**[Garden of Bones](/wiki/Garden_of_Bones_(episode) "Garden of Bones (episode)")**
[The Ghost of Harrenhal](/wiki/The_Ghost_of_Harrenhal "The Ghost of Harrenhal")
[The Old Gods and the New](/wiki/The_Old_Gods_and_the_New "The Old Gods and the New")
[A Man Without Honor](/wiki/A_Man_Without_Honor "A Man Without Honor")
[The Prince of Winterfell](/wiki/The_Prince_of_Winterfell "The Prince of Winterfell")
[Blackwater](/wiki/Blackwater "Blackwater")
[Valar Morghulis](/wiki/Valar_Morghulis "Valar Morghulis")
## See also\[\]
- [![](https://static.wikia.nocookie.net/gameofthrones/images/4/40/Imdb2.PNG/revision/latest?cb=20230112120149)](https://static.wikia.nocookie.net/gameofthrones/images/4/40/Imdb2.PNG/revision/latest?cb=20230112120149) [Kelly Long](https://www.imdb.com/name/nm4958677/) on [IMDb](https://imdb.com)
- [![](https://static.wikia.nocookie.net/gameofthrones/images/f/f7/Twitter.png/revision/latest?cb=20230831203024)](https://static.wikia.nocookie.net/gameofthrones/images/f/f7/Twitter.png/revision/latest?cb=20230831203024) [Kelly Long](https://www.twitter.com/KellyLongLegs/) on [𝕏](https://twitter.com)
- [![](https://static.wikia.nocookie.net/gameofthrones/images/5/55/Facebook.png/revision/latest?cb=20210924212448)](https://static.wikia.nocookie.net/gameofthrones/images/5/55/Facebook.png/revision/latest?cb=20210924212448) [Kelly Long](https://www.facebook.com/kellylongactor/) on [Facebook](https://facebook.com)
- [Interview with Kelly Long at The Time Warriors.](http://www.thetimewarriors.co.uk/blog/?p=13217)
## References\[\]
1. [↑](#cite_ref-1 "Jump up") [The Film Lobby: Kelly Long](http://web.archive.org/web/20131207212039/http://thefilmlobby.com/users/77) (archived December 7, 2013 from [\[1\]](http://www.thefilmlobby.com/users/77))
2. [↑](#cite_ref-2 "Jump up") [EG’s very own Princess, Kelly Long](http://www.thetimewarriors.co.uk/blog/?p=8002)
Categories
- [Categories](/wiki/Special:Categories "Special:Categories"):
- [Guest starring cast members of Game of Thrones](/wiki/Category:Guest_starring_cast_members_of_Game_of_Thrones "Category:Guest starring cast members of Game of Thrones")
- [Stunt performers of Game of Thrones](/wiki/Category:Stunt_performers_of_Game_of_Thrones "Category:Stunt performers of Game of Thrones")
[\[Configure Reference Popups\]](#configure-refpopups)
Languages
[Deutsch](https://gameofthrones.fandom.com/de/wiki/Kelly_Long) [Français](https://gameofthrones.fandom.com/fr/wiki/Kelly_Long)
Community content is available under [CC-BY-SA](https://www.fandom.com/licensing) unless otherwise noted.
More Fandoms
- [Fantasy](https://www.fandom.com/fancentral/fantasy)
- [Game of Thrones](https://www.fandom.com/universe/game-of-thrones)