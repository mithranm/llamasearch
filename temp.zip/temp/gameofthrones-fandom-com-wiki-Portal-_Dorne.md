## https://gameofthrones.fandom.com/wiki/Portal:_Dorne

in: [Portals](/wiki/Category:Portals "Category:Portals")
# Portal: Dorne
[View source](/wiki/Portal:_Dorne?action=edit)
- [History](/wiki/Portal:_Dorne?action=history)
- [Purge](/wiki/Portal:_Dorne?action=purge)
- [Talk (0)](/wiki/Talk:Portal:_Dorne?action=edit&redlink=1)
Dorne
[**Dorne**](/wiki/Dorne "Dorne")
[![Dorne](https://static.wikia.nocookie.net/gameofthrones/images/f/f5/Dorne.png/revision/latest/scale-to-width-down/330?cb=20120719190909)](/wiki/Dorne "Dorne")
[**House Martell**](/wiki/House_Martell "House Martell")
[![House Martell](https://static.wikia.nocookie.net/gameofthrones/images/3/39/Mar-Portal.png/revision/latest?cb=20160303113324)](/wiki/House_Martell "House Martell")
[**The Dornishmen**](/wiki/Dornishmen "Dornishmen")
[![Dornishmen](https://static.wikia.nocookie.net/gameofthrones/images/e/ef/DornishBannermen.jpg/revision/latest/scale-to-width-down/330?cb=20140211223224)](/wiki/Dornishmen "Dornishmen")
[**The Rhoynar**](/wiki/Rhoynar "Rhoynar")
[![Rhoynar](https://static.wikia.nocookie.net/gameofthrones/images/2/26/Rhoynar_alliance.png/revision/latest/scale-to-width-down/330?cb=20160920201523)](/wiki/Rhoynar "Rhoynar")
[**Paramour**](/wiki/Paramour "Paramour")
[![Paramour](https://static.wikia.nocookie.net/gameofthrones/images/3/3e/Oberyn-Martell-IEllaria-Sand_s4_Kings_landing.jpg/revision/latest/scale-to-width-down/330?cb=20160814003335)](/wiki/Paramour "Paramour")
[**Bastards**](/wiki/Bastard "Bastard")
[![Bastard](https://static.wikia.nocookie.net/gameofthrones/images/e/eb/EllariaBastardsVid.jpg/revision/latest/scale-to-width-down/330?cb=20160814011027)](/wiki/Bastard "Bastard")
[**The Water Gardens**](/wiki/Water_Gardens "Water Gardens")
[![Water Gardens](https://static.wikia.nocookie.net/gameofthrones/images/7/71/Dorne_Season_5.png/revision/latest/scale-to-width-down/330?cb=20150130222749)](/wiki/Water_Gardens "Water Gardens")
[**Nymeria**](/wiki/Nymeria "Nymeria")
[![Nymeria](https://static.wikia.nocookie.net/gameofthrones/images/3/3f/H%26L401.png/revision/latest/scale-to-width-down/330?cb=20240821132527)](/wiki/Nymeria "Nymeria")
[**House Dayne**](/wiki/House_Dayne "House Dayne")
[![House Dayne](https://static.wikia.nocookie.net/gameofthrones/images/9/96/Ser_Arthur_Dayne_%28right%29_at_the_Tower_of_Joy.png/revision/latest/scale-to-width-down/330?cb=20160509035404)](/wiki/House_Dayne "House Dayne")
[**The Sand Snakes**](/wiki/Sand_Snakes "Sand Snakes")
[![Sand Snakes](https://static.wikia.nocookie.net/gameofthrones/images/6/6f/Ellaria_sand_and_the_sand_snakes_game_of_thrones_finale_s6.jpg/revision/latest/scale-to-width-down/330?cb=20160814010326)](/wiki/Sand_Snakes "Sand Snakes")
Categories
- [Categories](/wiki/Special:Categories "Special:Categories"):
- [Portals](/wiki/Category:Portals "Category:Portals")
[\[Configure Reference Popups\]](#configure-refpopups)
Community content is available under [CC-BY-SA](https://www.fandom.com/licensing) unless otherwise noted.
More Fandoms
- [Fantasy](https://www.fandom.com/fancentral/fantasy)
- [Game of Thrones](https://www.fandom.com/universe/game-of-thrones)