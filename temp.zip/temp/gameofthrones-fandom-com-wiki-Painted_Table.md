## https://gameofthrones.fandom.com/wiki/Painted_Table

## Contents
- [1 History](#History)
- [1.1 Game of Thrones: Season 2](#Game_of_Thrones:_Season_2)
- [1.2 Game of Thrones: Season 7](#Game_of_Thrones:_Season_7)
- [1.3 Game of Thrones: Season 8](#Game_of_Thrones:_Season_8)
- [2 In the books](#In_the_books)
- [3 References](#References)
- [3.1 Notes](#Notes)
- [4 External links](#External_links)
in: [Pages on canon subjects](/wiki/Category:Pages_on_canon_subjects "Category:Pages on canon subjects"), [Dragonstone](/wiki/Category:Dragonstone "Category:Dragonstone"), [House Baratheon of Dragonstone](/wiki/Category:House_Baratheon_of_Dragonstone "Category:House Baratheon of Dragonstone"),
and [2 more](null)
- [House Targaryen](/wiki/Category:House_Targaryen "Category:House Targaryen")
- [Objects](/wiki/Category:Objects "Category:Objects")
English
- [Deutsch](https://gameofthrones.fandom.com/de/wiki/Bemalte_Tafel)
- [Français](https://gameofthrones.fandom.com/fr/wiki/Chambre_de_la_Table_Peinte)
- [Русский](https://gameofthrones.fandom.com/ru/wiki/%D0%A0%D0%B0%D1%81%D0%BF%D0%B8%D1%81%D0%BD%D0%BE%D0%B9_%D1%81%D1%82%D0%BE%D0%BB)
# Painted Table
[Sign in to edit](https://auth.fandom.com/signin?redirect=https%3A%2F%2Fgameofthrones.fandom.com%2Fwiki%2FPainted_Table%3Fveaction%3Dedit&uselang=en)
- [History](/wiki/Painted_Table?action=history)
- [Purge](/wiki/Painted_Table?action=purge)
- [Talk (3)](/wiki/Talk:Painted_Table)
Netflix: Electric State Cast Interview
We sat down with the cast of Electric State, coming March 14th on Netflix.
Keep WatchingNext video in 8 seconds
More Videos
0 of 2 minutes, 51 secondsVolume 0%
Press shift question mark to access a list of keyboard shortcuts
Keyboard ShortcutsEnabledDisabled
Shortcuts Open/Close/ or ?
Play/PauseSPACE
Increase Volume↑
Decrease Volume↓
Seek Forward→
Seek Backward←
Captions On/Offc
Fullscreen/Exit Fullscreenf
Mute/Unmutem
Decrease Caption Size\-
Increase Caption Size\+ or =
Seek %0-9
Auto720p1080p720p406p270p180p
0.5x1x1.25x1.5x2x
Live
00:09
02:41
02:51
[![Painted Table](https://static.wikia.nocookie.net/gameofthrones/images/6/60/Painted_Table.jpg/revision/latest/scale-to-width-down/300?cb=20221026151105)
](https://static.wikia.nocookie.net/gameofthrones/images/6/60/Painted_Table.jpg/revision/latest?cb=20221026151105)
The Painted Table, lit by candles underneath.
The **Painted Table**[\[1\]](#cite_note-HOTD_110-1) is a table carved in the shape of [Westeros](/wiki/Westeros "Westeros"), engraved with its major cities, castles, and landmarks. In [132 AC](/wiki/132_AC "132 AC"),[\[a\]](#cite_note-The_Lord_of_the_Tides_year-2) it was located in the eponymous **Chamber of the Painted Table**.[\[2\]](#cite_note-Dragonstone-3) By [299 AC](/wiki/299_AC "299 AC"),[\[b\]](#cite_note-Game_of_Thrones_Season_2_year-4) it was located in what was once [Rhaenyra Targaryen](/wiki/Rhaenyra_Targaryen "Rhaenyra Targaryen")'s apartments.[\[3\]](#cite_note-GOT_201-5)[\[2\]](#cite_note-Dragonstone-3)
## Contents
- [1 History](#History)
- [1.1 Game of Thrones: Season 2](#Game_of_Thrones:_Season_2)
- [1.2 Game of Thrones: Season 7](#Game_of_Thrones:_Season_7)
- [1.3 Game of Thrones: Season 8](#Game_of_Thrones:_Season_8)
- [2 In the books](#In_the_books)
- [3 References](#References)
- [3.1 Notes](#Notes)
- [4 External links](#External_links)
Advertisement
## History\[\]
### [_Game of Thrones_: Season 2](/wiki/Game_of_Thrones:_Season_2 "Game of Thrones: Season 2")\[\]
[Stannis Baratheon](/wiki/Stannis_Baratheon "Stannis Baratheon") holds meetings with his court around the Painted Table. After receiving [Eddard Stark](/wiki/Eddard_Stark "Eddard Stark")'s message concerning the true heritage of King [Robert](/wiki/Robert_Baratheon "Robert Baratheon")'s children, Stannis dictates a letter to his scribe in the Chamber of the Painted Table to be sent to lords throughout the land revealing this information and therefore establishing his claim to the [Iron Throne](/wiki/Iron_Throne "Iron Throne") as the rightful heir. Maester [Cressen](/wiki/Cressen "Cressen") tries to poison [Melisandre](/wiki/Melisandre "Melisandre") in the chamber to remove her influence over Stannis, only to die from the poison himself while Melisandre is unharmed.[\[4\]](#cite_note-6)
Melisandre seduces Stannis on the table, which leads to the birth of the [shadow](/wiki/Shadow "Shadow") she uses to assassinate Stannis's brother and rival [Renly Baratheon](/wiki/Renly_Baratheon "Renly Baratheon").[\[5\]](#cite_note-7)
After his defeat at the [Battle of the Blackwater](/wiki/Battle_of_the_Blackwater "Battle of the Blackwater"), Stannis returns to Dragonstone and confronts Melisandre in the Chamber of the Painted Table about the validity of her predictions. He begins to strangle her in fury but relents when she reminds him of the spell they used to kill Renly. He experiences remorse of murdering his brother. Melisandre warns him that he will commit worse betrayals before their long war is over but insists that he must fight on. She shows him a vision in the flames that awes him and restores his faith in her.[\[6\]](#cite_note-8)
### [_Game of Thrones_: Season 7](/wiki/Game_of_Thrones:_Season_7 "Game of Thrones: Season 7")\[\]
After [Daenerys Targaryen](/wiki/Daenerys_Targaryen "Daenerys Targaryen")'s fleet arrives from [Meereen](/wiki/Meereen "Meereen"), her first act is to seize Dragonstone, as both a symbolic gesture (the location of her birth and the ancestral home of House Targaryen) and a strategic one (deep ports to moor her ships and proximity to King's Landing). After exploring the castle, Daenerys and her [Hand](/wiki/Hand_of_the_King "Hand of the King"), [Tyrion Lannister](/wiki/Tyrion_Lannister "Tyrion Lannister"), arrive in the Chamber to prepare for the war for the rest of Westeros, as Aegon the Conqueror once had.[\[7\]](#cite_note-9) The following day, Daenerys grills Varys on his true loyalties, comparing his desire for a [Targaryen](/wiki/House_Targaryen "House Targaryen") restoration to that of Viserys, in which she also states that Varys only supported her when it suited him, and followed Viserys until his death. She also questions why he betrayed her father for Robert, to which he explains that he would have been executed if he had not done so and that he obeyed Robert's strength in contrast to Aerys' cruelty. Varys then makes it clear that he is truly a representative of the common people. Daenerys then requests that Varys make a promise to advise her when she goes wrong, rather than betray her, to which he concedes.[\[8\]](#cite_note-Stormborn-10)
[![Stormborn Dany's Council](https://static.wikia.nocookie.net/gameofthrones/images/2/2a/Stormborn_Dany%27s_Council.jpg/revision/latest/scale-to-width-down/180?cb=20170725181907)
](https://static.wikia.nocookie.net/gameofthrones/images/2/2a/Stormborn_Dany%27s_Council.jpg/revision/latest?cb=20170725181907)
Daenerys and Tyrion plan her conquest at the table.
Later, Tyrion plans the [Last War](/wiki/Last_War "Last War"). There, Daenerys later stops the arguing between [Ellaria Sand](/wiki/Ellaria_Sand "Ellaria Sand") and Tyrion over [the assassination of Myrcella Baratheon](/wiki/Assassination_of_Myrcella_Baratheon "Assassination of Myrcella Baratheon"), to which Daenerys replies Ellaria must respect her Hand. She also agrees with Tyrion over Yara's idea to attack King's Landing immediately, and that the Unsullied should attack [Casterly Rock](/wiki/Casterly_Rock "Casterly Rock") while the Westerosi armies lay siege to the capital. When everyone has left the chamber, she requests an audience alone with [Olenna Tyrell](/wiki/Olenna_Tyrell "Olenna Tyrell"). Daenerys then tells her that she knows Olenna is on her side due to their mutual hatred for Cersei, rather than a love for Daenerys herself. In response, Olenna encourages Dany to be a [dragon](/wiki/Dragon "Dragon"), rather than a "sheep", like the other high lords and ladies.[\[8\]](#cite_note-Stormborn-10)
Later, at the Chamber of the Painted Table, Jon tells Daenerys about the news of his half-brother Bran and half-sister Arya Stark's return to Winterfell. He warns Daenerys' about Bran's vision of the Army of the Dead marching towards Eastwatch-by-the-Sea. Tyrion is present and proposes bring a Wight south in order to prove that the Army of the Dead and the White Walkers are real. Varys opines that it is suicide trying to appeal to Queen Cersei Lannister but Tyrion argues that he can persuade his brother Jaime.
Davos also thinks such a mission is risky even for a smuggler like him. Jorah volunteers to go north to help capture a Wight while Jon volunteers to lead such the expedition. Apparently on the verge of tears about the idea of Jon leaving, Daenerys responds that she did not give Jon permission to leave but Jon reminds her that he is the King in the North. He tells her she has the power of life and death over him but that he trusted her even though she was a stranger. He pleads with her to return the favor by trusting him.[\[9\]](#cite_note-11)
Advertisement
### [_Game of Thrones_: Season 8](/wiki/Game_of_Thrones:_Season_8 "Game of Thrones: Season 8")\[\]
Daenerys meets with Grey Worm, Varys, and Tyrion in the chamber to discuss the strategy to take King's Landing following [Missandei](/wiki/Missandei "Missandei")'s capture. Daenerys, seems intent on using dragonfire to take King's Landing. Varys interjects, telling her that what she is planning is a mistake. Daenerys ignores him, but agrees to Parley with Cersei to give her one last chance to release Missandei and surrender.[\[10\]](#cite_note-12)
Later, Daenerys watches the view of [Blackwater Bay](/wiki/Blackwater_Bay "Blackwater Bay") from the Chamber, saddened due to the loss of Missandei. Tyrion arrives to tell her of Varys's betrayal, and she responds by chastising him for his failure to inform her about his knowledge of Jon's parentage.
She later tries to seduce Jon in the chamber, but he rejects her, after telling her that he loved her. Seeing Jon's rejection of her and concluding that she cannot rule with love, she resolves to [rule through fear](/wiki/Battle_of_King%27s_Landing "Battle of King's Landing").[\[11\]](#cite_note-13)
## In the books\[\]
In the _[A Song of Ice and Fire](/wiki/A_Song_of_Ice_and_Fire "A Song of Ice and Fire")_ novels, the Chamber of the Painted Table is located at the top of the central keep of Dragonstone, called the Stone Drum. It has four tall windows facing each point of the compass. [Aegon the Conqueror](/wiki/Aegon_I_Targaryen "Aegon I Targaryen") planned his [invasion](/wiki/Aegon%27s_Conquest "Aegon's Conquest") of the [Seven Kingdoms](/wiki/Seven_Kingdoms "Seven Kingdoms") from the chamber. The Painted Table itself is more than fifty feet long: roughly twenty-five feet wide at its widest point and four feet at its thinnest. At the precise location of Dragonstone is a raised seat that allows the occupant to view the entire map. The series omits this raised seat, with Stannis sitting at the head of the table near Dorne and the Reach (the Wall can be glimpsed at the opposite end of the table from where Stannis sits). It's location has also been changed, as it now seems to be located further down in the keep and has only a single window taking up an entire wall, carved directly into the cliff face.
## References\[\]
1. [↑](#cite_ref-HOTD_110_1-0 "Jump up") _[House of the Dragon](/wiki/House_of_the_Dragon "House of the Dragon")_: [Season 1](/wiki/House_of_the_Dragon:_Season_1 "House of the Dragon: Season 1"), Episode 10: "[The Black Queen](/wiki/The_Black_Queen "The Black Queen")" (2022).
2. ↑ [Jump up to: 2.0](#cite_ref-Dragonstone_3-0) [2.1](#cite_ref-Dragonstone_3-1) [Dragonstone](https://www.hbo.com/house-of-the-dragon/map-of-westeros#dragonstone). HBO. Retrieved March 15, 2023.
3. [↑](#cite_ref-GOT_201_5-0 "Jump up") _[Game of Thrones](/wiki/Game_of_Thrones "Game of Thrones")_: [Season 2](/wiki/Game_of_Thrones:_Season_2 "Game of Thrones: Season 2"), Episode 1: "[The North Remembers](/wiki/The_North_Remembers "The North Remembers")" (2012).
4. [↑](#cite_ref-6 "Jump up") "[The North Remembers](/wiki/The_North_Remembers "The North Remembers")"
5. [↑](#cite_ref-7 "Jump up") "[The Night Lands](/wiki/The_Night_Lands "The Night Lands")"
6. [↑](#cite_ref-8 "Jump up") "[Valar Morghulis](/wiki/Valar_Morghulis "Valar Morghulis")"
7. [↑](#cite_ref-9 "Jump up") "[Dragonstone](/wiki/Dragonstone_(episode) "Dragonstone (episode)")"
8. ↑ [Jump up to: 8.0](#cite_ref-Stormborn_10-0) [8.1](#cite_ref-Stormborn_10-1) "[Stormborn](/wiki/Stormborn "Stormborn")"
9. [↑](#cite_ref-11 "Jump up") "[Eastwatch](/wiki/Eastwatch "Eastwatch")"
10. [↑](#cite_ref-12 "Jump up") "[The Last of the Starks](/wiki/The_Last_of_the_Starks "The Last of the Starks")"
11. [↑](#cite_ref-13 "Jump up") "[The Bells](/wiki/The_Bells "The Bells")"
### Notes\[\]
1. [↑](#cite_ref-The_Lord_of_the_Tides_year_2-0 "Jump up") The premise of "[The Lord of the Tides](/wiki/The_Lord_of_the_Tides "The Lord of the Tides")" opens with "six years later." The previous episode takes place in 126 AC.
2. [↑](#cite_ref-Game_of_Thrones_Season_2_year_4-0 "Jump up") In "[Winter Is Coming](/wiki/Winter_Is_Coming "Winter Is Coming")," which takes place in 298 AC, Sansa Stark tells Cersei Lannister that she is 13 years old and Bran Stark tells Jaime Lannister that he is 10 years old. Arya Stark was born between Sansa and Bran, making her either 11 or 12 in Season 1. The rest of the Stark children have been aged up by 2 years from their book ages, so it can be assumed that she is 11 in Season 1. Arya is 18 in Season 8 [according to HBO](https://twitter.com/HBO_UK/status/1119989670182576128?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1119989670182576128%7Ctwgr%5Ef16ac13db9086bf98859287354e64f0d2142cc11%7Ctwcon%5Es1_&ref_url=https%3A%2F%2Fd-10646340663989370207.ampproject.net%2F2304212144000%2Fframe.html), which means at least 7 years occur in the span of the series; therefore, each season of _Game of Thrones_ must roughly correspond to a year in-universe, placing the events of Season 2 in 299 AC.
## External links\[\]
- [![](https://static.wikia.nocookie.net/gameofthrones/images/6/63/A_Wiki_of_Ice_and_Fire_favicon.PNG/revision/latest/scale-to-width-down/25?cb=20140327143233)](https://static.wikia.nocookie.net/gameofthrones/images/6/63/A_Wiki_of_Ice_and_Fire_favicon.PNG/revision/latest?cb=20140327143233) [Painted Table](https://awoiaf.westeros.org/index.php/Painted_Table "awoiaf:Painted Table") on [A Wiki of Ice and Fire](https://awoiaf.westeros.org/)
Categories
- [Categories](/wiki/Special:Categories "Special:Categories"):
- [Pages on canon subjects](/wiki/Category:Pages_on_canon_subjects "Category:Pages on canon subjects")
- [Dragonstone](/wiki/Category:Dragonstone "Category:Dragonstone")
- [House Baratheon of Dragonstone](/wiki/Category:House_Baratheon_of_Dragonstone "Category:House Baratheon of Dragonstone")
- [House Targaryen](/wiki/Category:House_Targaryen "Category:House Targaryen")
- [Objects](/wiki/Category:Objects "Category:Objects")
[\[Configure Reference Popups\]](#configure-refpopups)
Languages
[Deutsch](https://gameofthrones.fandom.com/de/wiki/Bemalte_Tafel) [Français](https://gameofthrones.fandom.com/fr/wiki/Chambre_de_la_Table_Peinte) [Русский](https://gameofthrones.fandom.com/ru/wiki/%D0%A0%D0%B0%D1%81%D0%BF%D0%B8%D1%81%D0%BD%D0%BE%D0%B9_%D1%81%D1%82%D0%BE%D0%BB)
Community content is available under [CC-BY-SA](https://www.fandom.com/licensing) unless otherwise noted.
More Fandoms
- [Fantasy](https://www.fandom.com/fancentral/fantasy)
- [Game of Thrones](https://www.fandom.com/universe/game-of-thrones)