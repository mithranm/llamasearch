## https://gameofthrones.fandom.com/wiki/Simon_Strong

## Contents
- [1 Biography](#Biography)
- [1.1 Background](#Background)
- [1.2 House of the Dragon: Season 2](#House_of_the_Dragon:_Season_2)
- [2 Quotes](#Quotes)
- [3 Family](#Family)
- [4 Behind the scenes](#Behind_the_scenes)
- [5 In the books](#In_the_books)
- [6 Appearances](#Appearances)
- [7 References](#References)
- [8 External links](#External_links)
in: [Pages on canon subjects](/wiki/Category:Pages_on_canon_subjects "Category:Pages on canon subjects"), [Blacks](/wiki/Category:Blacks "Category:Blacks"), [Castellans](/wiki/Category:Castellans "Category:Castellans"),
and [5 more](null)
- [Greens](/wiki/Category:Greens "Category:Greens")
- [Individuals appearing in House of the Dragon](/wiki/Category:Individuals_appearing_in_House_of_the_Dragon "Category:Individuals appearing in House of the Dragon")
- [Knights](/wiki/Category:Knights "Category:Knights")
- [Members of House Strong](/wiki/Category:Members_of_House_Strong "Category:Members of House Strong")
- [Rivermen](/wiki/Category:Rivermen "Category:Rivermen")
English
- [Español](https://hieloyfuego.fandom.com/wiki/Simon_Strong/House_of_the_Dragon)
- [Français](https://gameofthrones.fandom.com/fr/wiki/Simon_Fort)
- [Polski](https://gameofthrones.fandom.com/pl/wiki/Simon_Strong)
- [Русский](https://gameofthrones.fandom.com/ru/wiki/%D0%A1%D0%B0%D0%B9%D0%BC%D0%BE%D0%BD_%D0%A1%D1%82%D1%80%D0%BE%D0%BD%D0%B3)
- [Українська](https://gameofthrones.fandom.com/uk/wiki/%D0%A1%D0%B0%D0%B9%D0%BC%D0%BE%D0%BD_%D0%94%D1%83%D0%B6%D0%B8%D0%B9)
# Simon Strong
[Sign in to edit](https://auth.fandom.com/signin?redirect=https%3A%2F%2Fgameofthrones.fandom.com%2Fwiki%2FSimon_Strong%3Fveaction%3Dedit&uselang=en)
- [History](/wiki/Simon_Strong?action=history)
- [Purge](/wiki/Simon_Strong?action=purge)
- [Talk (0)](/wiki/Talk:Simon_Strong?action=edit&redlink=1)
Netflix: Electric State Cast Interview
We sat down with the cast of Electric State, coming March 14th on Netflix.
Keep WatchingNext video in 8 seconds
More Videos
0 of 15 secondsVolume 0%
Press shift question mark to access a list of keyboard shortcuts
Keyboard ShortcutsEnabledDisabled
Shortcuts Open/Close/ or ?
Play/PauseSPACE
Increase Volume↑
Decrease Volume↓
Seek Forward→
Seek Backward←
Captions On/Offc
Fullscreen/Exit Fullscreenf
Mute/Unmutem
Decrease Caption Size\-
Increase Caption Size\+ or =
Seek %0-9
0.5x1x1.25x1.5x2x
Auto180p1080p720p406p270p180p
This ad will end in 3
Live
00:12
00:02
00:15
[![](https://static.wikia.nocookie.net/gameofthrones/images/3/36/House_Strong.svg/revision/latest/scale-to-width-down/50?cb=20230905234103)](/wiki/House_Strong "House Strong")
[![](https://static.wikia.nocookie.net/gameofthrones/images/3/36/House_Strong.svg/revision/latest/scale-to-width-down/50?cb=20230905234103)](/wiki/House_Strong "House Strong")
## Simon Strong
[![Simon Strong](https://static.wikia.nocookie.net/gameofthrones/images/a/ae/Simon_Strong.jpg/revision/latest/scale-to-width-down/268?cb=20240701071129)
](https://static.wikia.nocookie.net/gameofthrones/images/a/ae/Simon_Strong.jpg/revision/latest?cb=20240701071129 "Simon Strong")
## Political information
### House(s)
[Strong](/wiki/House_Strong "House Strong")
### Affiliation(s)
[Greens](/wiki/Greens "Greens") (formerly)[Blacks](/wiki/Blacks "Blacks")[\[1\]](#cite_note-HOTD_203-1)
### Title(s)
[Ser](/wiki/Knighthood "Knighthood")[Castellan](/wiki/Castellan "Castellan") of [Harrenhal](/wiki/Harrenhal "Harrenhal")
## Personal information
### Culture
[Rivermen](/wiki/Riverlands "Riverlands")
## _World of Westeros_
### Series
_[House of the Dragon](/wiki/House_of_the_Dragon "House of the Dragon")_
### Season(s)
[2](/wiki/House_of_the_Dragon:_Season_2 "House of the Dragon: Season 2")
### Appeared in
6 episodes ([see below](#Appearances))
### First seen in
"[The Burning Mill](/wiki/The_Burning_Mill "The Burning Mill")"
### Portrayed by
[Simon Russell Beale](/wiki/Simon_Russell_Beale "Simon Russell Beale")
"_I, Ser Simon Strong, castellan of Harrenhal, swear fealty to Rhaenyra of House Targaryen, the First of Her Name. I swear this by the Old Gods, and the New._"
―Simon Strong capitulates to Daemon Targaryen[\[src\]](/wiki/The_Burning_Mill "The Burning Mill")
Ser **Simon Strong** is a [knight](/wiki/Knighthood "Knighthood") of [House Strong](/wiki/House_Strong "House Strong") during the [Dance of the Dragons](/wiki/Dance_of_the_Dragons "Dance of the Dragons").
## Contents
- [1 Biography](#Biography)
- [1.1 Background](#Background)
- [1.2 House of the Dragon: Season 2](#House_of_the_Dragon:_Season_2)
- [2 Quotes](#Quotes)
- [3 Family](#Family)
- [4 Behind the scenes](#Behind_the_scenes)
- [5 In the books](#In_the_books)
- [6 Appearances](#Appearances)
- [7 References](#References)
- [8 External links](#External_links)
Advertisement
## Biography\[\]
### Background\[\]
Simon is the uncle of [Lyonel Strong](/wiki/Lyonel_Strong "Lyonel Strong") and granduncle of [Larys Strong](/wiki/Larys_Strong "Larys Strong") and [Harwin Strong](/wiki/Harwin_Strong "Harwin Strong"). He serves as the [castellan](/wiki/Castellan "Castellan") of [Harrenhal](/wiki/Harrenhal "Harrenhal").[\[1\]](#cite_note-HOTD_203-1)
### [_House of the Dragon_: Season 2](/wiki/House_of_the_Dragon:_Season_2 "House of the Dragon: Season 2")\[\]
When Prince [Daemon Targaryen](/wiki/Daemon_Targaryen "Daemon Targaryen") and his [dragon](/wiki/Dragon "Dragon") [Caraxes](/wiki/Caraxes "Caraxes") arrive at Harrenhal to claim the castle for the [Blacks](/wiki/Blacks "Blacks"), Ser Simon hastily bends the knee and declares his allegiance to Queen [Rhaenyra Targaryen](/wiki/Rhaenyra_Targaryen "Rhaenyra Targaryen"), inviting Daemon to dine with him. Over dinner, Simon assures Daemon, who refuses to touch his plate, that the food isn't poisoned and he is welcome in the castle. When Daemon questions Simon's submission, given the lord of his house has declared for [Aegon](/wiki/Aegon_II_Targaryen "Aegon II Targaryen"), Simon brands his great-nephew Larys a scourge on their family, making it clear he believes Larys [murdered](/wiki/Kinslaying "Kinslaying") [his father](/wiki/Lyonel_Strong "Lyonel Strong") and [brother](/wiki/Harwin_Strong "Harwin Strong") to claim lordship of Harrenhal, noting the suspicious nature of the fire that claimed their lives. Simon then converses with Daemon about making [House Tully](/wiki/House_Tully/House_of_the_Dragon "House Tully/House of the Dragon") declare for the Blacks.[\[1\]](#cite_note-HOTD_203-1)
Simon awakens Daemon from a nightmare to inform him that a [raven](/wiki/Raven "Raven") has arrived, warning [Criston Cole](/wiki/Criston_Cole "Criston Cole")'s army has departed King's Landing, Houses [Rosby](/wiki/House_Rosby "House Rosby") and [Stokeworth](/wiki/House_Stokeworth "House Stokeworth") have defected to the [Greens](/wiki/Greens "Greens") and added their forces to Cole's, and Cole is likely making for Harrenhal. Simon expresses his concern even if Daemon can raise an army in the Riverlands, it may not be ready in time to face Cole. Simon also introduces Daemon to [Oscar Tully](/wiki/Oscar_Tully "Oscar Tully"), grandson and heir to Lord [Grover Tully](/wiki/Grover_Tully "Grover Tully"). After Oscar informs Daemon of his grandfather's deteriorating health and his lack of authority to speak in Grover's stead, Daemon mocks House Tully as "a fish without a head" to Simon and questions which side in the [recent clash](/wiki/Battle_at_the_Burning_Mill "Battle at the Burning Mill") between Houses [Blackwood](/wiki/House_Blackwood "House Blackwood") and [Bracken](/wiki/House_Bracken "House Bracken") declared for Rhaenyra. Once informed the Brackens declared for Aegon, Daemon orders Simon to summon the Blackwoods to Harrenhal. Simon is later present when Daemon negotiates with Ser [Willem Blackwood](/wiki/Willem_Blackwood "Willem Blackwood").[\[2\]](#cite_note-HOTD_204-2)
## Quotes\[\]
**Simon**: "_You should know that a substantial number of those swords have now declared and are presently at war. Houses Bracken and Blackwood have long detested one another._"
**Daemon**: "_Why?_"
**Simon**: "_Oh, well... the answer to that is lost in time. Sin begets sin begets sin._"
— Simon Strong[\[src\]](/wiki/The_Burning_Mill "The Burning Mill")
## Family\[\]
[![](https://static.wikia.nocookie.net/gameofthrones/images/8/8a/House-Strong-Square.PNG/revision/latest/scale-to-width-down/100?cb=20230403091741)](/wiki/House_Strong "House Strong")
LordStrong_Deceased_
[![](https://static.wikia.nocookie.net/gameofthrones/images/8/8a/House-Strong-Square.PNG/revision/latest/scale-to-width-down/100?cb=20230403091741)](/wiki/House_Strong "House Strong")
LadyStrong
[![](https://static.wikia.nocookie.net/gameofthrones/images/2/2a/Famtree-Simon_Strong.png/revision/latest/scale-to-width-down/100?cb=20240620074912)](/wiki/Simon_Strong "Simon Strong")
**SimonStrong**
[![](https://static.wikia.nocookie.net/gameofthrones/images/8/8a/House-Strong-Square.PNG/revision/latest/scale-to-width-down/100?cb=20230403091741)](/wiki/House_Strong "House Strong")
Wife
[![](https://static.wikia.nocookie.net/gameofthrones/images/b/bb/Famtree-Lyonel_Strong.png/revision/latest/scale-to-width-down/100?cb=20220825084018)](/wiki/Lyonel_Strong "Lyonel Strong")
[LyonelStrong](/wiki/Lyonel_Strong "Lyonel Strong")_Deceased_
[![](https://static.wikia.nocookie.net/gameofthrones/images/8/8a/House-Strong-Square.PNG/revision/latest/scale-to-width-down/100?cb=20230403091741)](/wiki/House_Strong "House Strong")
Wives
[![](https://static.wikia.nocookie.net/gameofthrones/images/8/8a/House-Strong-Square.PNG/revision/latest/scale-to-width-down/100?cb=20230403091741)](/wiki/House_Strong "House Strong")
Son(s)
[![](https://static.wikia.nocookie.net/gameofthrones/images/6/61/Famtree-HarwinStrong.png/revision/latest/scale-to-width-down/100?cb=20220908154742)](/wiki/Harwin_Strong "Harwin Strong")
[HarwinStrong](/wiki/Harwin_Strong "Harwin Strong") [![City Watch of King's Landing/House of the Dragon](https://static.wikia.nocookie.net/gameofthrones/images/7/75/City_Watch_of_King%27s_Landing.svg/revision/latest/scale-to-width-down/16?cb=20230905222737)](/wiki/City_Watch_of_King%27s_Landing/House_of_the_Dragon "City Watch of King's Landing/House of the Dragon")_Deceased_
[![](https://static.wikia.nocookie.net/gameofthrones/images/2/2e/Famtree-RhaenyraTargaryen.png/revision/latest/scale-to-width-down/100?cb=20220926053249)](/wiki/Rhaenyra_Targaryen "Rhaenyra Targaryen")
[RhaenyraTargaryen](/wiki/Rhaenyra_Targaryen "Rhaenyra Targaryen") [![House Targaryen/House of the Dragon](https://static.wikia.nocookie.net/gameofthrones/images/1/1e/House_Targaryen.svg/revision/latest/scale-to-width-down/16?cb=20230905234715)](/wiki/House_Targaryen/House_of_the_Dragon "House Targaryen/House of the Dragon")
[![](https://static.wikia.nocookie.net/gameofthrones/images/b/bf/Famtree-Larys_Strong.png/revision/latest/scale-to-width-down/100?cb=20220908154457)](/wiki/Larys_Strong "Larys Strong")
[LarysStrong](/wiki/Larys_Strong "Larys Strong")
[![](https://static.wikia.nocookie.net/gameofthrones/images/9/9d/Famtree-Germund_Strong.png/revision/latest/scale-to-width-down/100?cb=20240708060619)](/wiki/Germund_Strong "Germund Strong")
[GermundStrong](/wiki/Germund_Strong "Germund Strong")
[![](https://static.wikia.nocookie.net/gameofthrones/images/a/a6/Famtree-Paxter_Strong.png/revision/latest/scale-to-width-down/100?cb=20240708060632)](/wiki/Paxter_Strong "Paxter Strong")
[PaxterStrong](/wiki/Paxter_Strong "Paxter Strong")
[![](https://static.wikia.nocookie.net/gameofthrones/images/d/dd/Famtree-Jacaerys_Velaryon.png/revision/latest/scale-to-width-down/100?cb=20221007232955)](/wiki/Jacaerys_Velaryon "Jacaerys Velaryon")
[JacaerysVelaryon](/wiki/Jacaerys_Velaryon "Jacaerys Velaryon") [![House Velaryon](https://static.wikia.nocookie.net/gameofthrones/images/5/5f/House_Velaryon.svg/revision/latest/scale-to-width-down/16?cb=20230905235447)](/wiki/House_Velaryon "House Velaryon")
[![](https://static.wikia.nocookie.net/gameofthrones/images/e/e4/Famtree-Lucerys_Velaryon.png/revision/latest/scale-to-width-down/100?cb=20221007233018)](/wiki/Lucerys_Velaryon "Lucerys Velaryon")
[LucerysVelaryon](/wiki/Lucerys_Velaryon "Lucerys Velaryon") [![House Velaryon](https://static.wikia.nocookie.net/gameofthrones/images/5/5f/House_Velaryon.svg/revision/latest/scale-to-width-down/16?cb=20230905235447)](/wiki/House_Velaryon "House Velaryon")_Deceased_
[![](https://static.wikia.nocookie.net/gameofthrones/images/c/c3/Famtree-JoffreyVelaryon.png/revision/latest/scale-to-width-down/100?cb=20221007233132)](/wiki/Joffrey_Velaryon "Joffrey Velaryon")
[JoffreyVelaryon](/wiki/Joffrey_Velaryon "Joffrey Velaryon") [![House Velaryon](https://static.wikia.nocookie.net/gameofthrones/images/5/5f/House_Velaryon.svg/revision/latest/scale-to-width-down/16?cb=20230905235447)](/wiki/House_Velaryon "House Velaryon")
Advertisement
## Behind the scenes\[\]
On April 24, 2023, [HBO](/wiki/HBO "HBO") announced that [Simon Russell Beale](/wiki/Simon_Russell_Beale "Simon Russell Beale") had been cast in the role of Simon Strong for [_House of the Dragon_: Season 2](/wiki/House_of_the_Dragon:_Season_2 "House of the Dragon: Season 2").[\[3\]](#cite_note-Variety-3) His character description reads as follows:
_"The great uncle to Lord Larys and castellan of Harrenhal."_[\[4\]](#cite_note-WBD-4)
## In the books\[\]
In _[Fire & Blood](/wiki/Fire_%26_Blood "Fire & Blood")_, Simon is Lyonel Strong's uncle. It is unknown if his brother was Lord Bywin Strong, the first Strong to hold Harrenhal.
## Appearances\[\]
- [![](https://static.wikia.nocookie.net/gameofthrones/images/f/fc/House_of_the_Dragon.png/revision/latest/scale-to-width-down/158?cb=20240522231410)](/wiki/House_of_the_Dragon "House of the Dragon") – "[The Burning Mill](/wiki/The_Burning_Mill "The Burning Mill")"
- [![](https://static.wikia.nocookie.net/gameofthrones/images/f/fc/House_of_the_Dragon.png/revision/latest/scale-to-width-down/158?cb=20240522231410)](/wiki/House_of_the_Dragon "House of the Dragon") – "[The Red Dragon and the Gold](/wiki/The_Red_Dragon_and_the_Gold "The Red Dragon and the Gold")"
- [![](https://static.wikia.nocookie.net/gameofthrones/images/f/fc/House_of_the_Dragon.png/revision/latest/scale-to-width-down/158?cb=20240522231410)](/wiki/House_of_the_Dragon "House of the Dragon") – "[Regent](/wiki/Regent_(episode) "Regent (episode)")"
- [![](https://static.wikia.nocookie.net/gameofthrones/images/f/fc/House_of_the_Dragon.png/revision/latest/scale-to-width-down/158?cb=20240522231410)](/wiki/House_of_the_Dragon "House of the Dragon") – "[Smallfolk](/wiki/Smallfolk_(episode) "Smallfolk (episode)")"
- [![](https://static.wikia.nocookie.net/gameofthrones/images/f/fc/House_of_the_Dragon.png/revision/latest/scale-to-width-down/158?cb=20240522231410)](/wiki/House_of_the_Dragon "House of the Dragon") – "[The Red Sowing](/wiki/The_Red_Sowing "The Red Sowing")"
- [![](https://static.wikia.nocookie.net/gameofthrones/images/f/fc/House_of_the_Dragon.png/revision/latest/scale-to-width-down/158?cb=20240522231410)](/wiki/House_of_the_Dragon "House of the Dragon") – "[The Queen Who Ever Was](/wiki/The_Queen_Who_Ever_Was "The Queen Who Ever Was")"
## References\[\]
1. ↑ [Jump up to: 1.0](#cite_ref-HOTD_203_1-0) [1.1](#cite_ref-HOTD_203_1-1) [1.2](#cite_ref-HOTD_203_1-2) _[House of the Dragon](/wiki/House_of_the_Dragon "House of the Dragon")_: [Season 2](/wiki/House_of_the_Dragon:_Season_2 "House of the Dragon: Season 2"), Episode 3: "[The Burning Mill](/wiki/The_Burning_Mill "The Burning Mill")" (2024).
2. [↑](#cite_ref-HOTD_204_2-0 "Jump up") _[House of the Dragon](/wiki/House_of_the_Dragon "House of the Dragon")_: [Season 2](/wiki/House_of_the_Dragon:_Season_2 "House of the Dragon: Season 2"), Episode 4: "[The Red Dragon and the Gold](/wiki/The_Red_Dragon_and_the_Gold "The Red Dragon and the Gold")" (2024).
3. [↑](#cite_ref-Variety_3-0 "Jump up") Jordan Moreau (April 24, 2023). [‘House of the Dragon’ Season 2 Casts Alys Rivers and Three More Characters](https://variety.com/2023/tv/news/house-of-the-dragon-alys-rivers-season-2-1235592500/). _Variety_. Retrieved April 25, 2023.
4. [↑](#cite_ref-WBD_4-0 "Jump up") Unknown author (Unknown date). [House of the Dragon S2 | Character Descriptions](https://press.wbd.com/us/bio/house-dragon-s2-character-descriptions). _Warner Bros. Discovery_. Retrieved June 5, 2024.
## External links\[\]
- [![](https://static.wikia.nocookie.net/gameofthrones/images/6/63/A_Wiki_of_Ice_and_Fire_favicon.PNG/revision/latest/scale-to-width-down/25?cb=20140327143233)](https://static.wikia.nocookie.net/gameofthrones/images/6/63/A_Wiki_of_Ice_and_Fire_favicon.PNG/revision/latest?cb=20140327143233) [Simon Strong](https://awoiaf.westeros.org/index.php/Simon_Strong "awoiaf:Simon Strong") on [A Wiki of Ice and Fire](https://awoiaf.westeros.org/) **(potential spoilers for _[House of the Dragon](/wiki/House_of_the_Dragon "House of the Dragon")_)**
[v](/wiki/Template:House_Strong "Template:House Strong") • [d](https://gameofthrones.fandom.com/wiki/Template_talk:House_Strong) • [e](https://gameofthrones.fandom.com/wiki/Template:House_Strong?action=edit)
[House Strong](/wiki/House_Strong "House Strong")
**Head**
[Larys Strong](/wiki/Larys_Strong "Larys Strong")
**Heir**
_Unknown_
[![House Strong](https://static.wikia.nocookie.net/gameofthrones/images/3/36/House_Strong.svg/revision/latest/scale-to-width-down/100?cb=20230905234103)](/wiki/House_Strong "House Strong")
**Seat**
[Harrenhal](/wiki/Harrenhal "Harrenhal")
**Region**
[Riverlands](/wiki/Riverlands "Riverlands")
**Titles**
[Lord of Harrenhal](/wiki/Lord_of_Harrenhal "Lord of Harrenhal")
**Members**
**Simon Strong** · [Germund Strong](/wiki/Germund_Strong "Germund Strong") · [Paxter Strong](/wiki/Paxter_Strong "Paxter Strong")
**Deceased**
[Lyonel Strong](/wiki/Lyonel_Strong "Lyonel Strong") · [Harwin Strong](/wiki/Harwin_Strong "Harwin Strong")
**Household**
[Alys Rivers](/wiki/Alys_Rivers "Alys Rivers")
**Overlords**
[House Tully](/wiki/House_Tully/House_of_the_Dragon "House Tully/House of the Dragon")
\[hide\]
[v](/wiki/Template:House_of_the_Dragon "Template:House of the Dragon") • [d](https://gameofthrones.fandom.com/wiki/Template_talk:House_of_the_Dragon) • [e](https://gameofthrones.fandom.com/wiki/Template:House_of_the_Dragon?action=edit)
_[House of the Dragon](/wiki/House_of_the_Dragon "House of the Dragon")_
**[Showrunners](/wiki/Category:Showrunners_of_House_of_the_Dragon "Category:Showrunners of House of the Dragon")**
[Ryan Condal](/wiki/Ryan_Condal "Ryan Condal") · [Miguel Sapochnik](/wiki/Miguel_Sapochnik "Miguel Sapochnik") (formerly)
**[Individuals](/wiki/Category:Individuals_from_House_of_the_Dragon "Category:Individuals from House of the Dragon")**
[Viserys I Targaryen](/wiki/Viserys_I_Targaryen "Viserys I Targaryen") · [Daemon Targaryen](/wiki/Daemon_Targaryen "Daemon Targaryen") · [Rhaenyra Targaryen](/wiki/Rhaenyra_Targaryen "Rhaenyra Targaryen") · [Alicent Hightower](/wiki/Alicent_Hightower "Alicent Hightower") · [Otto Hightower](/wiki/Otto_Hightower "Otto Hightower") · [Corlys Velaryon](/wiki/Corlys_Velaryon "Corlys Velaryon") · [Rhaenys Targaryen](/wiki/Rhaenys_Targaryen "Rhaenys Targaryen") · [Criston Cole](/wiki/Criston_Cole "Criston Cole") · [Larys Strong](/wiki/Larys_Strong "Larys Strong") · [Mysaria](/wiki/Mysaria "Mysaria") · [Aegon II Targaryen](/wiki/Aegon_II_Targaryen "Aegon II Targaryen") · [Aemond Targaryen](/wiki/Aemond_Targaryen "Aemond Targaryen") · [Helaena Targaryen](/wiki/Helaena_Targaryen "Helaena Targaryen") · [Jacaerys Velaryon](/wiki/Jacaerys_Velaryon "Jacaerys Velaryon") · [Baela Targaryen](/wiki/Baela_Targaryen "Baela Targaryen") · [Rhaena Targaryen](/wiki/Rhaena_Targaryen "Rhaena Targaryen") · [Tyland Lannister](/wiki/Tyland_Lannister "Tyland Lannister") · [Jason Lannister](/wiki/Jason_Lannister "Jason Lannister") · [Gwayne Hightower](/wiki/Gwayne_Hightower "Gwayne Hightower") · [Alys Rivers](/wiki/Alys_Rivers "Alys Rivers") · [Orwyle](/wiki/Orwyle "Orwyle") · [Alyn of Hull](/wiki/Alyn_of_Hull "Alyn of Hull") · [Addam of Hull](/wiki/Addam_of_Hull "Addam of Hull") · [Ulf](/wiki/Ulf "Ulf") · [Hugh](/wiki/Hugh "Hugh") · [Cregan Stark](/wiki/Cregan_Stark "Cregan Stark") · [Kat](/wiki/Kat "Kat") · **Simon Strong**
**[Cast members](/wiki/Category:Cast_members_of_House_of_the_Dragon "Category:Cast members of House of the Dragon")**
[Starring cast](/wiki/Starring_cast_(House_of_the_Dragon) "Starring cast (House of the Dragon)"): [Paddy Considine](/wiki/Paddy_Considine "Paddy Considine") · [Matt Smith](/wiki/Matt_Smith "Matt Smith") · [Emma D'Arcy](/wiki/Emma_D%27Arcy "Emma D'Arcy") · [Olivia Cooke](/wiki/Olivia_Cooke "Olivia Cooke") · [Rhys Ifans](/wiki/Rhys_Ifans "Rhys Ifans") · [Steve Toussaint](/wiki/Steve_Toussaint "Steve Toussaint") · [Eve Best](/wiki/Eve_Best "Eve Best") · [Fabien Frankel](/wiki/Fabien_Frankel "Fabien Frankel") · [Matthew Needham](/wiki/Matthew_Needham "Matthew Needham") · [Sonoya Mizuno](/wiki/Sonoya_Mizuno "Sonoya Mizuno") · [Tom Glynn-Carney](/wiki/Tom_Glynn-Carney "Tom Glynn-Carney") · [Ewan Mitchell](/wiki/Ewan_Mitchell "Ewan Mitchell") · [Phia Saban](/wiki/Phia_Saban "Phia Saban") · [Harry Collett](/wiki/Harry_Collett "Harry Collett") · [Bethany Antonia](/wiki/Bethany_Antonia "Bethany Antonia") · [Phoebe Campbell](/wiki/Phoebe_Campbell "Phoebe Campbell") · [Jefferson Hall](/wiki/Jefferson_Hall "Jefferson Hall") · [Freddie Fox](/wiki/Freddie_Fox "Freddie Fox") · [Gayle Rankin](/wiki/Gayle_Rankin "Gayle Rankin") · [Kurt Egyiawan](/wiki/Kurt_Egyiawan "Kurt Egyiawan") · [Abubakar Salim](/wiki/Abubakar_Salim "Abubakar Salim") · [Clinton Liberty](/wiki/Clinton_Liberty "Clinton Liberty") · [Tom Bennett](/wiki/Tom_Bennett "Tom Bennett") · [Kieran Bew](/wiki/Kieran_Bew "Kieran Bew") · [Tom Taylor](/wiki/Tom_Taylor "Tom Taylor") · [Ellora Torchia](/wiki/Ellora_Torchia "Ellora Torchia") · [Simon Russell Beale](/wiki/Simon_Russell_Beale "Simon Russell Beale")
**[Seasons](/wiki/Category:Seasons_of_House_of_the_Dragon "Category:Seasons of House of the Dragon")**
[Season 1](/wiki/House_of_the_Dragon:_Season_1 "House of the Dragon: Season 1") ([cast](/wiki/House_of_the_Dragon:_Season_1/Cast "House of the Dragon: Season 1/Cast")) · [Season 2](/wiki/House_of_the_Dragon:_Season_2 "House of the Dragon: Season 2") ([cast](/wiki/House_of_the_Dragon:_Season_2/Cast "House of the Dragon: Season 2/Cast")) · [Season 3](/wiki/House_of_the_Dragon:_Season_3 "House of the Dragon: Season 3") ([cast](/wiki/House_of_the_Dragon:_Season_3/Cast "House of the Dragon: Season 3/Cast")) · [Season 4](/wiki/House_of_the_Dragon:_Season_4 "House of the Dragon: Season 4")
**[Episodes](/wiki/Category:Episodes_of_House_of_the_Dragon "Category:Episodes of House of the Dragon")**
**[Season 1](/wiki/Category:Episodes_of_House_of_the_Dragon:_Season_1 "Category:Episodes of House of the Dragon: Season 1")**
[The Heirs of the Dragon](/wiki/The_Heirs_of_the_Dragon "The Heirs of the Dragon") ([appearances](/wiki/The_Heirs_of_the_Dragon/Appearances "The Heirs of the Dragon/Appearances")) · [The Rogue Prince](/wiki/The_Rogue_Prince "The Rogue Prince") ([appearances](/wiki/The_Rogue_Prince/Appearances "The Rogue Prince/Appearances")) · [Second of His Name](/wiki/Second_of_His_Name "Second of His Name") ([appearances](/wiki/Second_of_His_Name/Appearances "Second of His Name/Appearances")) · [King of the Narrow Sea](/wiki/King_of_the_Narrow_Sea_(episode) "King of the Narrow Sea (episode)") ([appearances](/wiki/King_of_the_Narrow_Sea_(episode)/Appearances "King of the Narrow Sea (episode)/Appearances")) · [We Light the Way](/wiki/We_Light_the_Way "We Light the Way") ([appearances](/wiki/We_Light_the_Way/Appearances "We Light the Way/Appearances")) · [The Princess and the Queen](/wiki/The_Princess_and_the_Queen "The Princess and the Queen") ([appearances](/wiki/The_Princess_and_the_Queen/Appearances "The Princess and the Queen/Appearances")) · [Driftmark](/wiki/Driftmark_(episode) "Driftmark (episode)") ([appearances](/wiki/Driftmark_(episode)/Appearances "Driftmark (episode)/Appearances")) · [The Lord of the Tides](/wiki/The_Lord_of_the_Tides "The Lord of the Tides") ([appearances](/wiki/The_Lord_of_the_Tides/Appearances "The Lord of the Tides/Appearances")) · [The Green Council](/wiki/The_Green_Council "The Green Council") ([appearances](/wiki/The_Green_Council/Appearances "The Green Council/Appearances")) · [The Black Queen](/wiki/The_Black_Queen "The Black Queen") ([appearances](/wiki/The_Black_Queen/Appearances "The Black Queen/Appearances"))
**[Season 2](/wiki/Category:Episodes_of_House_of_the_Dragon:_Season_2 "Category:Episodes of House of the Dragon: Season 2")**
[A Son for a Son](/wiki/A_Son_for_a_Son "A Son for a Son") ([appearances](/wiki/A_Son_for_a_Son/Appearances "A Son for a Son/Appearances")) · [Rhaenyra the Cruel](/wiki/Rhaenyra_the_Cruel "Rhaenyra the Cruel") ([appearances](/wiki/Rhaenyra_the_Cruel/Appearances "Rhaenyra the Cruel/Appearances")) · [The Burning Mill](/wiki/The_Burning_Mill "The Burning Mill") ([appearances](/wiki/The_Burning_Mill/Appearances "The Burning Mill/Appearances")) · [The Red Dragon and the Gold](/wiki/The_Red_Dragon_and_the_Gold "The Red Dragon and the Gold") ([appearances](/wiki/The_Red_Dragon_and_the_Gold/Appearances "The Red Dragon and the Gold/Appearances")) · [Regent](/wiki/Regent_(episode) "Regent (episode)") ([appearances](/wiki/Regent_(episode)/Appearances "Regent (episode)/Appearances")) · [Smallfolk](/wiki/Smallfolk_(episode) "Smallfolk (episode)") ([appearances](/wiki/Smallfolk_(episode)/Appearances "Smallfolk (episode)/Appearances")) · [The Red Sowing](/wiki/The_Red_Sowing "The Red Sowing") ([appearances](/wiki/The_Red_Sowing/Appearances "The Red Sowing/Appearances")) · [The Queen Who Ever Was](/wiki/The_Queen_Who_Ever_Was "The Queen Who Ever Was") ([appearances](/wiki/The_Queen_Who_Ever_Was/Appearances "The Queen Who Ever Was/Appearances"))
**[Season 3](/wiki/Category:Episodes_of_House_of_the_Dragon:_Season_3 "Category:Episodes of House of the Dragon: Season 3")**
[Episode 1](/wiki/House_of_the_Dragon:_Season_3,_Episode_1 "House of the Dragon: Season 3, Episode 1") · [Episode 2](/wiki/House_of_the_Dragon:_Season_3,_Episode_2 "House of the Dragon: Season 3, Episode 2") · [Episode 3](/wiki/House_of_the_Dragon:_Season_3,_Episode_3 "House of the Dragon: Season 3, Episode 3") · [Episode 4](/wiki/House_of_the_Dragon:_Season_3,_Episode_4 "House of the Dragon: Season 3, Episode 4") · [Episode 5](/wiki/House_of_the_Dragon:_Season_3,_Episode_5 "House of the Dragon: Season 3, Episode 5") · [Episode 6](/wiki/House_of_the_Dragon:_Season_3,_Episode_6 "House of the Dragon: Season 3, Episode 6") · [Episode 7](/wiki/House_of_the_Dragon:_Season_3,_Episode_7 "House of the Dragon: Season 3, Episode 7") · [Episode 8](/wiki/House_of_the_Dragon:_Season_3,_Episode_8 "House of the Dragon: Season 3, Episode 8")
**[Season 4](/wiki/Category:Episodes_of_House_of_the_Dragon:_Season_4 "Category:Episodes of House of the Dragon: Season 4")**
[Episode 1](/wiki/House_of_the_Dragon:_Season_4,_Episode_1 "House of the Dragon: Season 4, Episode 1") · [Episode 2](/wiki/House_of_the_Dragon:_Season_4,_Episode_2 "House of the Dragon: Season 4, Episode 2") · [Episode 3](/wiki/House_of_the_Dragon:_Season_4,_Episode_3 "House of the Dragon: Season 4, Episode 3") · [Episode 4](/wiki/House_of_the_Dragon:_Season_4,_Episode_4 "House of the Dragon: Season 4, Episode 4") · [Episode 5](/wiki/House_of_the_Dragon:_Season_4,_Episode_5 "House of the Dragon: Season 4, Episode 5") · [Episode 6](/wiki/House_of_the_Dragon:_Season_4,_Episode_6 "House of the Dragon: Season 4, Episode 6") · [Episode 7](/wiki/House_of_the_Dragon:_Season_4,_Episode_7 "House of the Dragon: Season 4, Episode 7") · [Episode 8](/wiki/House_of_the_Dragon:_Season_4,_Episode_8 "House of the Dragon: Season 4, Episode 8")
**[Games](/wiki/Category:Games_based_on_House_of_the_Dragon "Category:Games based on House of the Dragon")**
_[Game of Thrones: Conquest](/wiki/Game_of_Thrones:_Conquest "Game of Thrones: Conquest")_ · _[House of the Dragon: DracARys](/wiki/House_of_the_Dragon:_DracARys "House of the Dragon: DracARys")_ · _[Game of Thrones: Legends](/wiki/Game_of_Thrones:_Legends "Game of Thrones: Legends")_
**[Podcast](/wiki/Category:Podcasts_of_House_of_the_Dragon "Category:Podcasts of House of the Dragon")**
_[The Official Game of Thrones Podcast: House of the Dragon](/wiki/The_Official_Game_of_Thrones_Podcast:_House_of_the_Dragon "The Official Game of Thrones Podcast: House of the Dragon")_ ([Season 1](/wiki/The_Official_Game_of_Thrones_Podcast:_House_of_the_Dragon:_Season_1 "The Official Game of Thrones Podcast: House of the Dragon: Season 1") · [2](/wiki/The_Official_Game_of_Thrones_Podcast:_House_of_the_Dragon:_Season_2 "The Official Game of Thrones Podcast: House of the Dragon: Season 2"))
**[Music](/wiki/Category:Music_from_House_of_the_Dragon "Category:Music from House of the Dragon")**
**[Themes and leitmotifs](/wiki/Category:Themes_and_leitmotifs "Category:Themes and leitmotifs")**
[Themes and leitmotifs](/wiki/Themes_and_leitmotifs_(House_of_the_Dragon) "Themes and leitmotifs (House of the Dragon)")
**[Albums](/wiki/Category:Albums_of_House_of_the_Dragon "Category:Albums of House of the Dragon")**
_[House of the Dragon: Season 1 (Soundtrack from the HBO Series)](/wiki/House_of_the_Dragon:_Season_1_(Soundtrack_from_the_HBO_Series) "House of the Dragon: Season 1 (Soundtrack from the HBO Series)")_ · _[House of the Dragon: Season 2 (Soundtrack from the HBO Series)](/wiki/House_of_the_Dragon:_Season_2_(Soundtrack_from_the_HBO_Series) "House of the Dragon: Season 2 (Soundtrack from the HBO Series)")_
**[Documentaries](/wiki/Category:Documentaries_of_House_of_the_Dragon "Category:Documentaries of House of the Dragon")**
_[House of the Dragon: Inside the Episode](/wiki/House_of_the_Dragon:_Inside_the_Episode "House of the Dragon: Inside the Episode")_ ([Season 1](/wiki/House_of_the_Dragon:_Inside_the_Episode:_Season_1 "House of the Dragon: Inside the Episode: Season 1") · [2](/wiki/House_of_the_Dragon:_Inside_the_Episode:_Season_2 "House of the Dragon: Inside the Episode: Season 2")) · _[House of the Dragon: The House That Dragons Built](/wiki/House_of_the_Dragon:_The_House_That_Dragons_Built "House of the Dragon: The House That Dragons Built")_ ([Season 1](/wiki/House_of_the_Dragon:_The_House_That_Dragons_Built:_Season_1 "House of the Dragon: The House That Dragons Built: Season 1") · [2](/wiki/House_of_the_Dragon:_The_House_That_Dragons_Built:_Season_2 "House of the Dragon: The House That Dragons Built: Season 2"))
**[Website](/wiki/Category:Websites_of_House_of_the_Dragon "Category:Websites of House of the Dragon")**
[_House of the Dragon_ Official Guide](/wiki/House_of_the_Dragon_Official_Guide "House of the Dragon Official Guide")
**[Books](/wiki/Category:Books_based_on_House_of_the_Dragon "Category:Books based on House of the Dragon")**
_[Game of Thrones: House of the Dragon: Inside the Creation of a Targaryen Dynasty](/wiki/Game_of_Thrones:_House_of_the_Dragon:_Inside_the_Creation_of_a_Targaryen_Dynasty "Game of Thrones: House of the Dragon: Inside the Creation of a Targaryen Dynasty")_ · _[House of the Dragon: The Official Coloring Book](/wiki/House_of_the_Dragon:_The_Official_Coloring_Book "House of the Dragon: The Official Coloring Book")_ · _[The Official Westeros Cookbook](/wiki/The_Official_Westeros_Cookbook "The Official Westeros Cookbook")_ · _Game of Thrones: House of the Dragon: Inside the Dawn of the Targaryen Civil War_
**Production**
[Filming locations](/wiki/Filming_locations_(House_of_the_Dragon) "Filming locations (House of the Dragon)")
**[Opening credits](/wiki/Category:Opening_credits_of_House_of_the_Dragon "Category:Opening credits of House of the Dragon")**
[Season 1](/wiki/Opening_credits_(House_of_the_Dragon:_Season_1) "Opening credits (House of the Dragon: Season 1)") · [Season 2](/wiki/Opening_credits_(House_of_the_Dragon:_Season_2) "Opening credits (House of the Dragon: Season 2)")
**[Source material](/wiki/Category:A_Song_of_Ice_and_Fire "Category:A Song of Ice and Fire")**
_[Fire & Blood](/wiki/Fire_%26_Blood "Fire & Blood")_
**[Differences in adaptation](/wiki/Category:Differences_in_adaptation_of_House_of_the_Dragon "Category:Differences in adaptation of House of the Dragon")**
[Season 1](/wiki/Differences_in_adaptation/House_of_the_Dragon:_Season_1 "Differences in adaptation/House of the Dragon: Season 1") · [Season 2](/wiki/Differences_in_adaptation/House_of_the_Dragon:_Season_2 "Differences in adaptation/House of the Dragon: Season 2")
Categories
- [Categories](/wiki/Special:Categories "Special:Categories"):
- [Pages on canon subjects](/wiki/Category:Pages_on_canon_subjects "Category:Pages on canon subjects")
- [Blacks](/wiki/Category:Blacks "Category:Blacks")
- [Castellans](/wiki/Category:Castellans "Category:Castellans")
- [Greens](/wiki/Category:Greens "Category:Greens")
- [Individuals appearing in House of the Dragon](/wiki/Category:Individuals_appearing_in_House_of_the_Dragon "Category:Individuals appearing in House of the Dragon")
- [Knights](/wiki/Category:Knights "Category:Knights")
- [Members of House Strong](/wiki/Category:Members_of_House_Strong "Category:Members of House Strong")
- [Rivermen](/wiki/Category:Rivermen "Category:Rivermen")
[\[Configure Reference Popups\]](#configure-refpopups)
Languages
[Español](https://hieloyfuego.fandom.com/wiki/Simon_Strong/House_of_the_Dragon) [Français](https://gameofthrones.fandom.com/fr/wiki/Simon_Fort) [Polski](https://gameofthrones.fandom.com/pl/wiki/Simon_Strong) [Русский](https://gameofthrones.fandom.com/ru/wiki/%D0%A1%D0%B0%D0%B9%D0%BC%D0%BE%D0%BD_%D0%A1%D1%82%D1%80%D0%BE%D0%BD%D0%B3) [Українська](https://gameofthrones.fandom.com/uk/wiki/%D0%A1%D0%B0%D0%B9%D0%BC%D0%BE%D0%BD_%D0%94%D1%83%D0%B6%D0%B8%D0%B9)
Community content is available under [CC-BY-SA](https://www.fandom.com/licensing) unless otherwise noted.
More Fandoms
- [Fantasy](https://www.fandom.com/fancentral/fantasy)
- [Game of Thrones](https://www.fandom.com/universe/game-of-thrones)